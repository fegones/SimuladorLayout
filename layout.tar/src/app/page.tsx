'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import InventoryAnalysis from '@/components/InventoryAnalysis'
import AnalysisResults from '@/components/AnalysisResults'
import { 
  Package, 
  Truck, 
  Target,
  Trophy,
  CheckCircle,
  XCircle,
  Info,
  Warehouse,
  Route,
  Lightbulb,
  AlertTriangle,
  Move,
  BarChart3,
  DollarSign,
  Activity,
  Layers,
  RefreshCw,
  Box,
  Tag,
  Archive,
  ShoppingCart,
  Filter,
  GraduationCap,
  ChevronLeft,
  ChevronRight,
  Play,
  BookOpen
} from 'lucide-react'

// Tipos de zona
type ZoneType = 'empty' | 'receiving' | 'storage_a' | 'storage_b' | 'storage_c' | 'picking' | 'shipping'

interface Cell {
  row: number
  col: number
  zone: ZoneType
  productType?: 'A' | 'B' | 'C'
}

export interface Product {
  id: string
  name: string
  category: 'A' | 'B' | 'C'
  rotationSpeed: 'high' | 'medium' | 'low'
  quantity: number
  unitValue: number
  entryDate: Date
  isPerishable?: boolean
}

interface Level {
  id: number
  name: string
  description: string
  objective: string
  constraints: string[]
  gridSize: number
  requiredZones: ZoneType[]
  targetEfficiency: number
  maxDistance: number
  budget: number
  zoneCosts: Record<ZoneType, number>
}

interface SimulationResult {
  score: number
  efficiency: number
  inventoryMethodScore: number
  budgetScore: number
  recommendations: string[]
  details: {
    layoutEfficiency: number
    inventoryCompatibility: number
    budgetUsage: number
    totalDistance: number
    abcCompliance: number
  }
}

interface GameState {
  currentLevel: number
  score: number
  usedBudget: number
  placedZones: Record<ZoneType, number>
  isComplete: boolean
  attempts: number
  resetPenalty: number
  inventoryMethod: 'FIFO' | 'LIFO'
  products: Product[]
  simulationResult?: SimulationResult
}

const ZONE_COLORS = {
  empty: 'bg-gray-100 border-gray-300 hover:bg-gray-200',
  receiving: 'bg-blue-500 border-blue-600 hover:bg-blue-600',
  storage_a: 'bg-red-500 border-red-600 hover:bg-red-600',
  storage_b: 'bg-yellow-500 border-yellow-600 hover:bg-yellow-600',
  storage_c: 'bg-gray-500 border-gray-600 hover:bg-gray-600',
  picking: 'bg-purple-500 border-purple-600 hover:bg-purple-600',
  shipping: 'bg-orange-500 border-orange-600 hover:bg-orange-600'
}

const ZONE_LABELS = {
  empty: 'Espacio vacío',
  receiving: 'Recepción',
  storage_a: 'Almacenaje A (Alta Rotación)',
  storage_b: 'Almacenaje B (Media Rotación)',
  storage_c: 'Almacenaje C (Baja Rotación)',
  picking: 'Picking',
  shipping: 'Área de Despachos'
}

const ZONE_ICONS = {
  receiving: <Truck className="w-4 h-4" />,
  storage_a: <Tag className="w-4 h-4" />,
  storage_b: <Box className="w-4 h-4" />,
  storage_c: <Archive className="w-4 h-4" />,
  picking: <ShoppingCart className="w-4 h-4" />,
  shipping: <Warehouse className="w-4 h-4" />
}

const LEVELS: Level[] = [
  {
    id: 1,
    name: "Nivel 1: Layout Básico con ABC",
    description: "Aprende los fundamentos del diseño de almacenes con clasificación ABC",
    objective: "Diseña un layout funcional con zonas ABC y gestión de rotación",
    constraints: [
      "Debes colocar todas las zonas requeridas incluyendo ABC",
      "Las zonas no pueden solaparse",
      "Presupuesto máximo: $120,000",
      "Eficiencia mínima: 40%",
      "Productos A cerca de picking, C en zonas lejanas"
    ],
    gridSize: 10,
    requiredZones: ['receiving', 'storage_a', 'storage_b', 'storage_c', 'picking', 'shipping'],
    targetEfficiency: 40,
    maxDistance: 50,
    budget: 120000,
    zoneCosts: {
      receiving: 15000,
      storage_a: 12000,
      storage_b: 10000,
      storage_c: 8000,
      picking: 12000,
      shipping: 15000,
      empty: 0
    }
  }
]

export default function WarehouseSimulator() {
  const [currentLevel, setCurrentLevel] = useState<Level>(LEVELS[0])
  const [grid, setGrid] = useState<Cell[][]>([])
  const [selectedZone, setSelectedZone] = useState<ZoneType>('receiving')
  const [gameState, setGameState] = useState<GameState>({
    currentLevel: 1,
    score: 0,
    usedBudget: 0,
    placedZones: { 
      empty: 0, 
      receiving: 0, 
      storage_a: 0, 
      storage_b: 0, 
      storage_c: 0, 
      picking: 0, 
      shipping: 0
    },
    isComplete: false,
    attempts: 0,
    resetPenalty: 0,
    inventoryMethod: 'FIFO',
    products: []
  })
  const [isSimulating, setIsSimulating] = useState(false)
  const [showExplanation, setShowExplanation] = useState(true)
  const [activeTab, setActiveTab] = useState<'layout' | 'inventory' | 'analysis'>('layout')
  
  // Tutorial state
  const [showTutorial, setShowTutorial] = useState(true)
  const [tutorialStep, setTutorialStep] = useState(0)
  const [showExample, setShowExample] = useState(false)
  const [exampleStep, setExampleStep] = useState(0)
  const [showStory, setShowStory] = useState(false)
  const [storyStep, setStoryStep] = useState(0)
  const [selectedMethod, setSelectedMethod] = useState<'FIFO' | 'LIFO' | null>(null)
  const [showInventory, setShowInventory] = useState(false)
  const [userProducts, setUserProducts] = useState<Product[]>([])

  // Add example state
  const [exampleProducts, setExampleProducts] = useState<Product[]>([])
  const [exampleLayout, setExampleLayout] = useState<(Product | null)[][]>([])
  const [isRunningExample, setIsRunningExample] = useState(false)
  const [currentFlowStep, setCurrentFlowStep] = useState(0)
  const [flowPath, setFlowPath] = useState<{row: number, col: number, product: Product}[]>([])

  // Inicializar cuadrícula y productos
  useEffect(() => {
    if (showExample) {
      initializeExample()
    } else if (!showStory && !showInventory) {
      initializeGrid()
      generateProducts()
    }
  }, [currentLevel, showExample, showStory, showInventory])

  const initializeGrid = () => {
    const newGrid: Cell[][] = []
    for (let row = 0; row < currentLevel.gridSize; row++) {
      newGrid[row] = []
      for (let col = 0; col < currentLevel.gridSize; col++) {
        newGrid[row][col] = {
          row,
          col,
          zone: 'empty'
        }
      }
    }
    setGrid(newGrid)
    setGameState(prev => ({
      ...prev,
      usedBudget: 0,
      placedZones: { 
        empty: 0, 
        receiving: 0, 
        storage_a: 0, 
        storage_b: 0, 
        storage_c: 0, 
        picking: 0, 
        shipping: 0
      },
      isComplete: false
    }))
  }

  // Generar productos ABC
  const generateProducts = () => {
    const products: Product[] = []
    
    // Generar productos A (20% del total) - Mayormente perecederos
    for (let i = 0; i < 20; i++) {
      products.push({
        id: `A-${i + 1}`,
        name: `Producto A-${i + 1}`,
        category: 'A',
        rotationSpeed: 'high',
        quantity: Math.floor(Math.random() * 50) + 10,
        unitValue: Math.floor(Math.random() * 500) + 100,
        entryDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
        isPerishable: true // Productos A son generalmente perecederos
      })
    }
    
    // Generar productos B (30% del total) - Algunos perecederos
    for (let i = 0; i < 30; i++) {
      products.push({
        id: `B-${i + 1}`,
        name: `Producto B-${i + 1}`,
        category: 'B',
        rotationSpeed: 'medium',
        quantity: Math.floor(Math.random() * 100) + 20,
        unitValue: Math.floor(Math.random() * 200) + 50,
        entryDate: new Date(Date.now() - Math.random() * 60 * 24 * 60 * 60 * 1000),
        isPerishable: Math.random() > 0.5 // 50% de productos B son perecederos
      })
    }
    
    // Generar productos C (50% del total) - Mayormente no perecederos
    for (let i = 0; i < 50; i++) {
      products.push({
        id: `C-${i + 1}`,
        name: `Producto C-${i + 1}`,
        category: 'C',
        rotationSpeed: 'low',
        quantity: Math.floor(Math.random() * 200) + 50,
        unitValue: Math.floor(Math.random() * 100) + 10,
        entryDate: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000),
        isPerishable: Math.random() > 0.8 // Solo 20% de productos C son perecederos
      })
    }
    
    setGameState(prev => ({ ...prev, products }))
  }

  // Initialize example scenario
  const initializeExample = () => {
    // Create example products for Ecuadorian company
    const exampleProductsList: Product[] = [
      // Productos A (Alta rotación - Exportación) - Perecederos
      { id: 'A-001', name: 'Banano Orgánico Premium', category: 'A', rotationSpeed: 'high', quantity: 1000, unitValue: 3.50, entryDate: new Date('2024-01-15'), isPerishable: true },
      { id: 'A-002', name: 'Rosa Ecuatoriana Roja', category: 'A', rotationSpeed: 'high', quantity: 500, unitValue: 2.80, entryDate: new Date('2024-01-16'), isPerishable: true },
      { id: 'A-003', name: 'Cacao Arriba Fino', category: 'A', rotationSpeed: 'high', quantity: 750, unitValue: 4.20, entryDate: new Date('2024-01-17'), isPerishable: false },
      { id: 'A-004', name: 'Atún Fresco Premium', category: 'A', rotationSpeed: 'high', quantity: 300, unitValue: 8.50, entryDate: new Date('2024-01-18'), isPerishable: true },
      { id: 'A-005', name: 'Quinua Orgánica', category: 'A', rotationSpeed: 'high', quantity: 600, unitValue: 3.20, entryDate: new Date('2024-01-19'), isPerishable: false },
      
      // Productos B (Media rotación - Mercado nacional) - Mixtos
      { id: 'B-001', name: 'Café Andino Especial', category: 'B', rotationSpeed: 'medium', quantity: 400, unitValue: 6.80, entryDate: new Date('2024-01-10'), isPerishable: false },
      { id: 'B-002', name: 'Chocolate Artesanal', category: 'B', rotationSpeed: 'medium', quantity: 250, unitValue: 5.50, entryDate: new Date('2024-01-11'), isPerishable: false },
      { id: 'B-003', name: 'Miel de Abeja Nativa', category: 'B', rotationSpeed: 'medium', quantity: 180, unitValue: 7.20, entryDate: new Date('2024-01-12'), isPerishable: true },
      { id: 'B-004', name: 'Piel de Lagarto', category: 'B', rotationSpeed: 'medium', quantity: 50, unitValue: 45.00, entryDate: new Date('2024-01-13'), isPerishable: false },
      { id: 'B-005', name: 'Sombrero de Paja Toquilla', category: 'B', rotationSpeed: 'medium', quantity: 120, unitValue: 25.00, entryDate: new Date('2024-01-14'), isPerishable: false },
      
      // Productos C (Baja rotación - Especializado) - No perecederos
      { id: 'C-001', name: 'Tagua Grabada Artesanal', category: 'C', rotationSpeed: 'low', quantity: 30, unitValue: 15.00, entryDate: new Date('2023-12-01'), isPerishable: false },
      { id: 'C-002', name: 'Panama Hat Premium', category: 'C', rotationSpeed: 'low', quantity: 20, unitValue: 120.00, entryDate: new Date('2023-12-15'), isPerishable: false },
      { id: 'C-003', name: 'Balsa Wood Crafts', category: 'C', rotationSpeed: 'low', quantity: 45, unitValue: 28.00, entryDate: new Date('2023-12-20'), isPerishable: false },
      { id: 'C-004', name: 'Orquídea Nativa', category: 'C', rotationSpeed: 'low', quantity: 15, unitValue: 35.00, entryDate: new Date('2024-01-05'), isPerishable: true },
      { id: 'C-005', name: 'Piedra de Jade', category: 'C', rotationSpeed: 'low', quantity: 8, unitValue: 250.00, entryDate: new Date('2023-11-30'), isPerishable: false }
    ]
    
    setExampleProducts(exampleProductsList)
    
    // Create optimal layout example
    const optimalLayout: (Product | null)[][] = Array(10).fill(null).map(() => Array(10).fill(null))
    
    // Place products in strategic positions
    optimalLayout[0][0] = exampleProductsList[0] // Banano en recepción
    optimalLayout[0][1] = exampleProductsList[1] // Rosas en recepción
    optimalLayout[1][0] = exampleProductsList[2] // Cacao cerca
    optimalLayout[1][1] = exampleProductsList[3] // Atún cerca
    
    // A products in high-access areas
    optimalLayout[2][2] = exampleProductsList[0]
    optimalLayout[2][3] = exampleProductsList[1]
    optimalLayout[3][2] = exampleProductsList[2]
    optimalLayout[3][3] = exampleProductsList[3]
    optimalLayout[4][2] = exampleProductsList[4]
    
    // B products in medium-access areas
    optimalLayout[2][6] = exampleProductsList[5]
    optimalLayout[2][7] = exampleProductsList[6]
    optimalLayout[3][6] = exampleProductsList[7]
    optimalLayout[3][7] = exampleProductsList[8]
    optimalLayout[4][6] = exampleProductsList[9]
    
    // C products in distant areas
    optimalLayout[7][7] = exampleProductsList[10]
    optimalLayout[7][8] = exampleProductsList[11]
    optimalLayout[8][7] = exampleProductsList[12]
    optimalLayout[8][8] = exampleProductsList[13]
    optimalLayout[9][7] = exampleProductsList[14]
    
    setExampleLayout(optimalLayout)
    setCurrentFlowStep(0)
    setFlowPath([])
  }

  // Run example flow simulation
  const runExampleFlow = async () => {
    setIsRunningExample(true)
    setCurrentFlowStep(0)
    
    // Define flow path for Ecuadorian company
    const flowSteps = [
      { row: 0, col: 0, product: exampleProducts[0], description: "Recepción: Banano Orgánico desde farms" },
      { row: 2, col: 2, product: exampleProducts[0], description: "Almacenaje A: Control de temperatura" },
      { row: 5, col: 4, product: exampleProducts[0], description: "Picking: Preparación pedido exportación" },
      { row: 9, col: 9, product: exampleProducts[0], description: "Despacho: Camino a puerto de Guayaquil" },
      
      { row: 0, col: 1, product: exampleProducts[1], description: "Recepción: Rosas desde Cayambe" },
      { row: 2, col: 3, product: exampleProducts[1], description: "Almacenaje A: Cámara fría" },
      { row: 5, col: 4, product: exampleProducts[1], description: "Picking: Empaque especial" },
      { row: 9, col: 9, product: exampleProducts[1], description: "Despacho: Vuelo internacional" },
      
      { row: 2, col: 6, product: exampleProducts[5], description: "Almacenaje B: Café desde Loja" },
      { row: 5, col: 4, product: exampleProducts[5], description: "Picking: Pedido mercado nacional" },
      { row: 9, col: 9, product: exampleProducts[5], description: "Despacho: Distribución local" },
      
      { row: 7, col: 7, product: exampleProducts[10], description: "Almacenaje C: Tagua artesanal" },
      { row: 5, col: 4, product: exampleProducts[10], description: "Picking: Pedido especial" },
      { row: 9, col: 9, product: exampleProducts[10], description: "Despacho: Tienda turística" }
    ]
    
    for (let i = 0; i < flowSteps.length; i++) {
      setCurrentFlowStep(i)
      setFlowPath([flowSteps[i]])
      await new Promise(resolve => setTimeout(resolve, 2000))
    }
    
    setIsRunningExample(false)
  }

  // Generate user inventory based on story
  const generateUserInventory = () => {
    const inventory: Product[] = [
      // Productos sin clasificar inicialmente - Productos A (Perecederos)
      { id: 'PROD-001', name: 'Fresas Frescas Orgánicas', category: 'A', rotationSpeed: 'high', quantity: 200, unitValue: 4.50, entryDate: new Date('2024-01-20'), isPerishable: true },
      { id: 'PROD-002', name: 'Leche Fresca Pasteurizada', category: 'A', rotationSpeed: 'high', quantity: 150, unitValue: 1.20, entryDate: new Date('2024-01-21'), isPerishable: true },
      { id: 'PROD-003', name: 'Yogurt Natural', category: 'A', rotationSpeed: 'high', quantity: 120, unitValue: 2.80, entryDate: new Date('2024-01-19'), isPerishable: true },
      { id: 'PROD-004', name: 'Pan Integral Fresco', category: 'A', rotationSpeed: 'high', quantity: 80, unitValue: 3.50, entryDate: new Date('2024-01-22'), isPerishable: true },
      { id: 'PROD-005', name: 'Huevos Orgánicos', category: 'A', rotationSpeed: 'high', quantity: 300, unitValue: 0.50, entryDate: new Date('2024-01-21'), isPerishable: true },
      { id: 'PROD-006', name: 'Tomates Frescos', category: 'A', rotationSpeed: 'high', quantity: 180, unitValue: 2.20, entryDate: new Date('2024-01-20'), isPerishable: true },
      { id: 'PROD-007', name: 'Pollo Fresco', category: 'A', rotationSpeed: 'high', quantity: 100, unitValue: 5.80, entryDate: new Date('2024-01-22'), isPerishable: true },
      { id: 'PROD-008', name: 'Pescado Fresco', category: 'A', rotationSpeed: 'high', quantity: 60, unitValue: 8.90, entryDate: new Date('2024-01-21'), isPerishable: true },
      
      // Productos B (Mixtos)
      { id: 'PROD-009', name: 'Arroz Blanco Grano Largo', category: 'B', rotationSpeed: 'medium', quantity: 500, unitValue: 1.80, entryDate: new Date('2024-01-10'), isPerishable: false },
      { id: 'PROD-010', name: 'Pasta Italiana', category: 'B', rotationSpeed: 'medium', quantity: 300, unitValue: 2.50, entryDate: new Date('2024-01-12'), isPerishable: false },
      { id: 'PROD-011', name: 'Aceite de Oliva Extra Virgen', category: 'B', rotationSpeed: 'medium', quantity: 80, unitValue: 12.00, entryDate: new Date('2024-01-08'), isPerishable: false },
      { id: 'PROD-012', name: 'Cereal Integral', category: 'B', rotationSpeed: 'medium', quantity: 150, unitValue: 4.20, entryDate: new Date('2024-01-15'), isPerishable: false },
      { id: 'PROD-013', name: 'Galletas Integrales', category: 'B', rotationSpeed: 'medium', quantity: 200, unitValue: 2.80, entryDate: new Date('2024-01-14'), isPerishable: false },
      { id: 'PROD-014', name: 'Mermelada Artesanal', category: 'B', rotationSpeed: 'medium', quantity: 90, unitValue: 5.50, entryDate: new Date('2024-01-11'), isPerishable: true },
      { id: 'PROD-015', name: 'Café en Grano Tostado', category: 'B', rotationSpeed: 'medium', quantity: 120, unitValue: 8.20, entryDate: new Date('2024-01-09'), isPerishable: false },
      { id: 'PROD-016', name: 'Té Verde Orgánico', category: 'B', rotationSpeed: 'medium', quantity: 60, unitValue: 6.80, entryDate: new Date('2024-01-13'), isPerishable: false },
      
      // Productos C (No perecederos)
      { id: 'PROD-017', name: 'Sal Marina Refinada', category: 'C', rotationSpeed: 'low', quantity: 1000, unitValue: 1.20, entryDate: new Date('2023-12-01'), isPerishable: false },
      { id: 'PROD-018', name: 'Azúcar Blanca', category: 'C', rotationSpeed: 'low', quantity: 800, unitValue: 1.50, entryDate: new Date('2023-12-15'), isPerishable: false },
      { id: 'PROD-019', name: 'Harina de Trigo', category: 'C', rotationSpeed: 'low', quantity: 600, unitValue: 2.20, entryDate: new Date('2023-12-20'), isPerishable: false },
      { id: 'PROD-020', name: 'Vinagre de Manzana', category: 'C', rotationSpeed: 'low', quantity: 200, unitValue: 3.80, entryDate: new Date('2024-01-05'), isPerishable: false },
      { id: 'PROD-021', name: 'Especias Variadas', category: 'C', rotationSpeed: 'low', quantity: 50, unitValue: 15.00, entryDate: new Date('2023-11-30'), isPerishable: false },
      { id: 'PROD-022', name: 'Conservas Vegetales', category: 'C', rotationSpeed: 'low', quantity: 150, unitValue: 4.50, entryDate: new Date('2024-01-02'), isPerishable: false },
      { id: 'PROD-023', name: 'Aceite Vegetal', category: 'C', rotationSpeed: 'low', quantity: 300, unitValue: 3.20, entryDate: new Date('2023-12-25'), isPerishable: false },
      { id: 'PROD-024', name: 'Chocolate en Polvo', category: 'C', rotationSpeed: 'low', quantity: 100, unitValue: 7.50, entryDate: new Date('2023-12-18'), isPerishable: false }
    ]
    
    setUserProducts(inventory)
    setGameState(prev => ({ ...prev, products: inventory }))
  }

  // Update product rotation speed
  const updateProductRotation = (productId: string, newRotation: 'high' | 'medium' | 'low') => {
    setUserProducts(prev => 
      prev.map(product => 
        product.id === productId 
          ? { ...product, rotationSpeed: newRotation }
          : product
      )
    )
    
    setGameState(prev => ({
      ...prev,
      products: prev.products.map(product => 
        product.id === productId 
          ? { ...product, rotationSpeed: newRotation }
          : product
      )
    }))
  }

  // Start user challenge
  const startUserChallenge = () => {
    generateUserInventory()
    setShowInventory(false)
    setShowExplanation(false)
    initializeGrid()
  }

  // Manejar clic en celda
  const handleCellClick = (row: number, col: number) => {
    if (isSimulating || gameState.isComplete) return

    const newGrid = [...grid]
    const oldZone = newGrid[row][col].zone
    const newZone = selectedZone

    // Verificar presupuesto
    const costDifference = currentLevel.zoneCosts[newZone] - currentLevel.zoneCosts[oldZone]
    if (gameState.usedBudget + costDifference > currentLevel.budget) {
      alert('¡Presupuesto insuficiente!')
      return
    }

    // Actualizar celda
    newGrid[row][col].zone = newZone
    
    // Asignar tipo de producto si es zona de almacenamiento
    if (newZone.includes('storage')) {
      if (newZone === 'storage_a') newGrid[row][col].productType = 'A'
      else if (newZone === 'storage_b') newGrid[row][col].productType = 'B'
      else if (newZone === 'storage_c') newGrid[row][col].productType = 'C'
    } else {
      newGrid[row][col].productType = undefined
    }
    
    setGrid(newGrid)

    // Actualizar estado del juego
    setGameState(prev => {
      const newPlacedZones = { ...prev.placedZones }
      newPlacedZones[oldZone]--
      newPlacedZones[newZone]++

      return {
        ...prev,
        usedBudget: prev.usedBudget + costDifference,
        placedZones: newPlacedZones
      }
    })
  }

  // Simular flujo con evaluación detallada
  const simulateFlow = () => {
    const zones = findZoneCenters()
    
    const missingZones = currentLevel.requiredZones.filter(zone => zones[zone] === null)
    if (missingZones.length > 0) {
      alert(`Faltan zonas requeridas: ${missingZones.map(z => ZONE_LABELS[z]).join(', ')}`)
      return
    }

    setIsSimulating(true)

    setTimeout(() => {
      const efficiency = calculateEfficiency()
      const evaluation = evaluateLayout()
      
      if (efficiency >= currentLevel.targetEfficiency && 
          gameState.usedBudget <= currentLevel.budget) {
        setGameState(prev => ({
          ...prev,
          isComplete: true,
          score: prev.score + Math.floor(efficiency * 10)
        }))
        
        showDetailedResults(efficiency, evaluation, true)
      } else {
        showDetailedResults(efficiency, evaluation, false)
        setIsSimulating(false)
      }
    }, 2000)
  }

  // Evaluación detallada del layout
  const evaluateLayout = () => {
    const zones = findZoneCenters()
    const issues: string[] = []
    const successes: string[] = []
    let score = 50
    
    // Evaluar método FIFO/LIFO
    const hasPerishables = userProducts.some(p => p.rotationSpeed === 'high')
    if (gameState.inventoryMethod === 'FIFO' && hasPerishables) {
      successes.push('✅ FIFO es excelente para productos perecederos - previenes pérdidas')
      score += 15
    } else if (gameState.inventoryMethod === 'LIFO' && hasPerishables) {
      issues.push('⚠️ LIFO con productos perecederos causará pérdidas por vencimiento')
      score -= 20
    }
    
    // Evaluar posición de zonas A
    if (zones.storage_a && zones.picking) {
      const distanceA = Math.abs(zones.storage_a.row - zones.picking.row) + Math.abs(zones.storage_a.col - zones.picking.col)
      if (distanceA <= 2) {
        successes.push(`✅ Zona A en posición óptima (coordenada ${String.fromCharCode(65 + zones.storage_a.row)}${zones.storage_a.col + 1}) - distancia ${distanceA} a picking`)
        score += 20
      } else if (distanceA <= 4) {
        successes.push(`✅ Zona A bien posicionada (coordenada ${String.fromCharCode(65 + zones.storage_a.row)}${zones.storage_a.col + 1}) - distancia ${distanceA} a picking`)
        score += 10
      } else {
        issues.push(`❌ Zona A demasiado lejos de picking (coordenada ${String.fromCharCode(65 + zones.storage_a.row)}${zones.storage_a.col + 1}) - distancia ${distanceA} afectará eficiencia`)
        score -= 15
      }
    }
    
    // Evaluar posición de zonas C
    if (zones.storage_c && zones.picking) {
      const distanceC = Math.abs(zones.storage_c.row - zones.picking.row) + Math.abs(zones.storage_c.col - zones.picking.col)
      if (distanceC >= 6) {
        successes.push(`✅ Zona C correctamente alejada (coordenada ${String.fromCharCode(65 + zones.storage_c.row)}${zones.storage_c.col + 1}) - distancia ${distanceC} de picking`)
        score += 15
      } else if (distanceC >= 4) {
        successes.push(`✅ Zona C a distancia aceptable (coordenada ${String.fromCharCode(65 + zones.storage_c.row)}${zones.storage_c.col + 1}) - distancia ${distanceC} de picking`)
        score += 8
      } else {
        issues.push(`❌ Zona C demasiado cerca de picking (coordenada ${String.fromCharCode(65 + zones.storage_c.row)}${zones.storage_c.col + 1}) - distancia ${distanceC} congestionará áreas de alta rotación`)
        score -= 10
      }
    }
    
    // Evaluar flujo recepción a despacho
    if (zones.receiving && zones.shipping) {
      const recToShip = Math.abs(zones.receiving.row - zones.shipping.row) + Math.abs(zones.receiving.col - zones.shipping.col)
      if (recToShip >= 8) {
        successes.push(`✅ Buen flujo lineal: Recepción (${String.fromCharCode(65 + zones.receiving.row)}${zones.receiving.col + 1}) → Despacho (${String.fromCharCode(65 + zones.shipping.row)}${zones.shipping.col + 1})`)
        score += 10
      } else {
        issues.push(`⚠️ Recepción y Despacho muy cercanos (distancia ${recToShip}) - puede causar congestión`)
        score -= 5
      }
    }
    
    // Evaluar clasificación de rotación
    const highRotationProducts = userProducts.filter(p => p.rotationSpeed === 'high').length
    const mediumRotationProducts = userProducts.filter(p => p.rotationSpeed === 'medium').length
    const lowRotationProducts = userProducts.filter(p => p.rotationSpeed === 'low').length
    
    if (highRotationProducts >= 6 && highRotationProducts <= 10) {
      successes.push(`✅ Buena clasificación de rotación: ${highRotationProducts} productos de alta rotación`)
      score += 5
    } else {
      issues.push(`⚠️ Revisa tu clasificación: ${highRotationProducts} productos de alta rotación (ideal: 6-10)`)
    }
    
    // Evaluar presupuesto
    const budgetUsage = (gameState.usedBudget / currentLevel.budget) * 100
    if (budgetUsage <= 80) {
      successes.push(`✅ Uso eficiente del presupuesto: ${budgetUsage.toFixed(1)}% utilizado`)
      score += 5
    } else if (budgetUsage > 95) {
      issues.push(`⚠️ Presupuesto casi agotado: ${budgetUsage.toFixed(1)}% utilizado`)
      score -= 5
    }
    
    return {
      score: Math.max(0, Math.min(100, score)),
      issues,
      successes,
      details: {
        method: gameState.inventoryMethod,
        hasPerishables,
        zones: zones,
        budgetUsage,
        highRotationProducts,
        mediumRotationProducts,
        lowRotationProducts
      }
    }
  }

  // Mostrar resultados detallados
  const showDetailedResults = (efficiency: number, evaluation: any, success: boolean) => {
    const resultMessage = `
📊 RESULTADOS DE EVALUACIÓN - ${success ? '¡ÉXITO!' : 'NECESITA MEJORAS'}

🎯 EFICIENCIA GENERAL: ${efficiency.toFixed(1)}%
📈 PUNTUACIÓN OBTENIDA: ${evaluation.score.toFixed(1)}/100

✅ ACIERTOS:
${evaluation.successes.length > 0 ? evaluation.successes.map((s: string) => `  ${s}`).join('\n') : '  Ningún acierto significativo'}

${evaluation.issues.length > 0 ? `⚠️ PROBLEMAS IDENTIFICADOS:
${evaluation.issues.map((i: string) => `  ${i}`).join('\n')}` : ''}

💰 PRESUPUESTO: ${((gameState.usedBudget / currentLevel.budget) * 100).toFixed(1)}% utilizado
📦 CLASIFICACIÓN: ${evaluation.details.highRotationProducts} alta, ${evaluation.details.mediumRotationProducts} media, ${evaluation.details.lowRotationProducts} baja rotación

${success ? 
  '🎉 ¡FELICITACIONES! Has diseñado un layout eficiente.' : 
  '🔧 RECOMENDACIONES ESPECÍFICAS:\n' + getSpecificRecommendations(evaluation)
}
    `
    
    alert(resultMessage)
  }

  // Generar recomendaciones específicas
  const getSpecificRecommendations = (evaluation: any): string => {
    const recommendations: string[] = []
    
    if (evaluation.details.method === 'LIFO' && evaluation.details.hasPerishables) {
      recommendations.push('• CAMBIA A FIFO: Tienes productos perecederos que se vencerán con LIFO')
    }
    
    if (evaluation.details.zones.storage_a && evaluation.details.zones.picking) {
      const distanceA = Math.abs(evaluation.details.zones.storage_a.row - evaluation.details.zones.picking.row) + 
                       Math.abs(evaluation.details.zones.storage_a.col - evaluation.details.zones.picking.col)
      if (distanceA > 4) {
        recommendations.push(`• ACERCA ZONA A: Mueve la zona A de ${String.fromCharCode(65 + evaluation.details.zones.storage_a.row)}${evaluation.details.zones.storage_a.col + 1} a una posición más cercana a picking (distancia actual: ${distanceA})`)
      }
    }
    
    if (evaluation.details.zones.storage_c && evaluation.details.zones.picking) {
      const distanceC = Math.abs(evaluation.details.zones.storage_c.row - evaluation.details.zones.picking.row) + 
                       Math.abs(evaluation.details.zones.storage_c.col - evaluation.details.zones.picking.col)
      if (distanceC < 4) {
        recommendations.push(`• ALEJA ZONA C: Mueve la zona C de ${String.fromCharCode(65 + evaluation.details.zones.storage_c.row)}${evaluation.details.zones.storage_c.col + 1} a una posición más lejana de picking (distancia actual: ${distanceC})`)
      }
    }
    
    if (evaluation.details.highRotationProducts < 6) {
      recommendations.push('• RECLASIFICA PRODUCTOS: Marca más productos como "Alta Rotación" - los perecederos deben ser alta rotación')
    }
    
    if (evaluation.details.budgetUsage > 90) {
      recommendations.push('• OPTIMIZA PRESUPUESTO: Elimina zonas innecesarias o usa zonas más económicas')
    }
    
    return recommendations.join('\n')
  }

  // Encontrar centros de zonas
  const findZoneCenters = () => {
    const zones: Record<ZoneType, { row: number; col: number }[]> = {
      empty: [],
      receiving: [],
      storage_a: [],
      storage_b: [],
      storage_c: [],
      picking: [],
      shipping: []
    }

    for (let row = 0; row < currentLevel.gridSize; row++) {
      for (let col = 0; col < currentLevel.gridSize; col++) {
        const zone = grid[row][col].zone
        if (zone !== 'empty') {
          zones[zone].push({ row, col })
        }
      }
    }

    const centers: Record<string, { row: number; col: number } | null> = {}
    Object.entries(zones).forEach(([zone, positions]) => {
      if (positions.length > 0) {
        const sumRow = positions.reduce((sum, pos) => sum + pos.row, 0)
        const sumCol = positions.reduce((sum, pos) => sum + pos.col, 0)
        centers[zone] = {
          row: Math.floor(sumRow / positions.length),
          col: Math.floor(sumCol / positions.length)
        }
      } else {
        centers[zone] = null
      }
    })

    return centers
  }

  // Calcular eficiencia
  const calculateEfficiency = (): number => {
    const centers = findZoneCenters()
    let efficiency = 50
    
    // Verificar ubicación ABC óptima
    if (centers.storage_a && centers.picking) {
      const distance = Math.abs(centers.storage_a.row - centers.picking.row) + Math.abs(centers.storage_a.col - centers.picking.col)
      if (distance <= 3) efficiency += 20
      else if (distance <= 5) efficiency += 10
    }
    
    if (centers.storage_c && centers.picking) {
      const distance = Math.abs(centers.storage_c.row - centers.picking.row) + Math.abs(centers.storage_c.col - centers.picking.col)
      if (distance >= 5) efficiency += 15
      else if (distance >= 3) efficiency += 8
    }
    
    return Math.min(100, efficiency)
  }

  // Obtener grid de almacén para análisis
  const getWarehouseGrid = (): Record<string, Product> => {
    const warehouseGrid: Record<string, Product> = {}
    
    // Simular productos colocados en el grid basado en las zonas
    // Grid es 10x10: columnas A-J (0-9), filas 1-10 (0-9)
    grid.forEach((row, rowIndex) => {
      row.forEach((cell, colIndex) => {
        if (cell.zone !== 'empty' && rowIndex < 10 && colIndex < 10) {
          // Coordenada correcta: Letra A-J + número 1-10
          const coordinate = `${String.fromCharCode(65 + colIndex)}${rowIndex + 1}`
          
          // Asignar productos a las zonas de almacenamiento
          if (cell.zone === 'storage_a' && gameState.products.length > 0) {
            const categoryAProducts = gameState.products.filter(p => p.category === 'A')
            if (categoryAProducts.length > 0) {
              const product = categoryAProducts[Math.floor(Math.random() * categoryAProducts.length)]
              warehouseGrid[coordinate] = product
            }
          } else if (cell.zone === 'storage_b' && gameState.products.length > 0) {
            const categoryBProducts = gameState.products.filter(p => p.category === 'B')
            if (categoryBProducts.length > 0) {
              const product = categoryBProducts[Math.floor(Math.random() * categoryBProducts.length)]
              warehouseGrid[coordinate] = product
            }
          } else if (cell.zone === 'storage_c' && gameState.products.length > 0) {
            const categoryCProducts = gameState.products.filter(p => p.category === 'C')
            if (categoryCProducts.length > 0) {
              const product = categoryCProducts[Math.floor(Math.random() * categoryCProducts.length)]
              warehouseGrid[coordinate] = product
            }
          }
        }
      })
    })
    
    return warehouseGrid
  }

  // Ejecutar simulación completa
  const runSimulation = () => {
    setIsSimulating(true)
    
    setTimeout(() => {
      const efficiency = calculateEfficiency()
      const centers = findZoneCenters()
      
      // Calcular score de método de inventario
      let inventoryScore = 50
      const perishableCount = gameState.products.filter(p => p.isPerishable).length
      const highRotationCount = gameState.products.filter(p => p.rotationSpeed === 'high').length
      
      if (gameState.inventoryMethod === 'FIFO') {
        if (perishableCount > gameState.products.length * 0.3) inventoryScore += 30
        if (highRotationCount > gameState.products.length * 0.5) inventoryScore += 20
      } else {
        if (perishableCount < gameState.products.length * 0.2) inventoryScore += 25
        if (highRotationCount < gameState.products.length * 0.3) inventoryScore += 25
      }
      
      // Calcular score de presupuesto
      const budgetUsage = (gameState.usedBudget / currentLevel.budget) * 100
      let budgetScore = 100
      if (budgetUsage > 100) budgetScore = 0
      else if (budgetUsage > 90) budgetScore = 30
      else if (budgetUsage > 80) budgetScore = 60
      else if (budgetUsage > 70) budgetScore = 80
      
      // Calcular distancia total
      let totalDistance = 0
      if (centers.receiving && centers.storage_a) {
        totalDistance += Math.abs(centers.receiving.row - centers.storage_a.row) + Math.abs(centers.receiving.col - centers.storage_a.col)
      }
      if (centers.storage_a && centers.picking) {
        totalDistance += Math.abs(centers.storage_a.row - centers.picking.row) + Math.abs(centers.storage_a.col - centers.picking.col)
      }
      if (centers.picking && centers.shipping) {
        totalDistance += Math.abs(centers.picking.row - centers.shipping.row) + Math.abs(centers.picking.col - centers.shipping.col)
      }
      
      // Calcular cumplimiento ABC
      let abcCompliance = 50
      if (centers.storage_a && centers.picking) {
        const distanceA = Math.abs(centers.storage_a.row - centers.picking.row) + Math.abs(centers.storage_a.col - centers.picking.col)
        if (distanceA <= 3) abcCompliance += 30
        else if (distanceA <= 5) abcCompliance += 15
      }
      if (centers.storage_c && centers.picking) {
        const distanceC = Math.abs(centers.storage_c.row - centers.picking.row) + Math.abs(centers.storage_c.col - centers.picking.col)
        if (distanceC >= 5) abcCompliance += 20
        else if (distanceC >= 3) abcCompliance += 10
      }
      
      // Generar recomendaciones
      const recommendations: string[] = []
      
      if (efficiency < 60) {
        recommendations.push("Considera mover la zona de almacenaje A más cerca del picking para mejorar eficiencia")
      }
      if (inventoryScore < 60) {
        if (gameState.inventoryMethod === 'FIFO' && perishableCount > 0) {
          recommendations.push("FIFO es una buena elección para tus productos perecederos")
        } else if (gameState.inventoryMethod === 'LIFO' && perishableCount > 0) {
          recommendations.push("Considera cambiar a FIFO para manejar mejor los productos perecederos")
        }
      }
      if (budgetUsage > 90) {
        recommendations.push("Estás cerca del límite del presupuesto. Considera optimizar el uso de zonas.")
      }
      if (totalDistance > 15) {
        recommendations.push("La distancia total del flujo es alta. Intenta compactar el layout.")
      }
      if (abcCompliance < 70) {
        recommendations.push("Mejora la distribución ABC: productos A cerca, productos C lejos")
      }
      
      if (recommendations.length === 0) {
        recommendations.push("¡Excelente diseño! Tu layout es eficiente y está bien optimizado.")
      }
      
      // Calcular score final
      const finalScore = Math.round(
        efficiency * 0.4 + 
        inventoryScore * 0.3 + 
        budgetScore * 0.2 + 
        abcCompliance * 0.1
      )
      
      const simulationResult: SimulationResult = {
        score: finalScore,
        efficiency,
        inventoryMethodScore: inventoryScore,
        budgetScore,
        recommendations,
        details: {
          layoutEfficiency: efficiency,
          inventoryCompatibility: inventoryScore,
          budgetUsage: Math.round(budgetUsage),
          totalDistance,
          abcCompliance
        }
      }
      
      setGameState(prev => ({
        ...prev,
        simulationResult,
        score: finalScore,
        isComplete: finalScore >= currentLevel.targetEfficiency
      }))
      
      setIsSimulating(false)
      setActiveTab('analysis')
    }, 2000)
  }

  // Reiniciar nivel sin penalización
  const resetLevel = () => {
    initializeGrid()
    generateProducts()
    setGameState(prev => ({
      ...prev,
      attempts: prev.attempts + 1,
      isComplete: false,
      simulationResult: undefined,
      usedBudget: 0,
      placedZones: { 
        empty: 0, 
        receiving: 0, 
        storage_a: 0, 
        storage_b: 0, 
        storage_c: 0, 
        picking: 0, 
        shipping: 0
      }
    }))
    setActiveTab('layout')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Tutorial Modal */}
        {showTutorial && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <GraduationCap className="w-6 h-6" />
                  Bienvenido al Simulador de Layout de Bodega Ecuatoriana
                </CardTitle>
                <CardDescription>
                  Aprende a diseñar layouts eficientes usando métodos ABC, FIFO y LIFO
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {tutorialStep === 0 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-green-800">🏭 Caso de Estudio: ExportAndes S.A.</h3>
                      <div className="space-y-3 text-sm">
                        <p><strong>Empresa:</strong> ExportAndes S.A. - Empresa ecuatoriana de exportación de productos agrícolas</p>
                        <p><strong>Ubicación:</strong> Cayambe, Ecuador - Cerca de Quito para acceso a aeropuerto internacional</p>
                        <p><strong>Mercado:</strong> Exportación a Estados Unidos, Europa y Asia (70%) + Mercado nacional (30%)</p>
                        <p><strong>Productos principales:</strong> Banano orgánico, rosas premium, cacao Arriba, café especializado</p>
                        <p><strong>Desafío:</strong> Diseñar una bodega que maneje eficientemente productos perecederos de exportación con diferentes temperaturas y requerimientos</p>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h4 className="font-bold mb-2">🎯 ¿Qué aprenderás?</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Clasificación ABC de productos según valor de exportación</li>
                        <li>Diseño de layout optimizado para productos perecederos</li>
                        <li>Gestión de inventario con FIFO para productos frescos</li>
                        <li>Optimización de rutas hacia puertos y aeropuertos</li>
                        <li>Criterios de diseño funcional y seguro</li>
                      </ul>
                    </div>
                  </div>
                )}

                {tutorialStep === 1 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-red-50 to-orange-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-red-800">🏷️ Análisis ABC - Productos de Exportación</h3>
                      <div className="space-y-4">
                        <div className="p-4 bg-red-100 rounded-lg">
                          <h4 className="font-bold text-red-900 mb-2">Categoría A (20% productos, 80% valor)</h4>
                          <ul className="text-sm space-y-1">
                            <li>• Banano Orgánico Premium ($3.50/unit) - 1000 unidades/mes</li>
                            <li>• Rosas Ecuatorianas Rojas ($2.80/unit) - 500 unidades/mes</li>
                            <li>• Cacao Arriba Fino ($4.20/unit) - 750 unidades/mes</li>
                            <li>• Atún Fresco Premium ($8.50/unit) - 300 unidades/mes</li>
                            <li><em>Requieren: control de temperatura, acceso rápido, zona cercana a despacho</em></li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-yellow-100 rounded-lg">
                          <h4 className="font-bold text-yellow-900 mb-2">Categoría B (30% productos, 15% valor)</h4>
                          <ul className="text-sm space-y-1">
                            <li>• Café Andino Especial ($6.80/unit) - 400 unidades/mes</li>
                            <li>• Chocolate Artesanal ($5.50/unit) - 250 unidades/mes</li>
                            <li>• Miel de Abeja Nativa ($7.20/unit) - 180 unidades/mes</li>
                            <li><em>Requieren: acceso medio, control de humedad, espacio intermedio</em></li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-gray-100 rounded-lg">
                          <h4 className="font-bold text-gray-900 mb-2">Categoría C (50% productos, 5% valor)</h4>
                          <ul className="text-sm space-y-1">
                            <li>• Tagua Grabada Artesanal ($15.00/unit) - 30 unidades/mes</li>
                            <li>• Panama Hat Premium ($120.00/unit) - 20 unidades/mes</li>
                            <li>• Balsa Wood Crafts ($28.00/unit) - 45 unidades/mes</li>
                            <li><em>Requieren: almacenamiento seco, acceso lejano, manejo cuidadoso</em></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {tutorialStep === 2 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-blue-800">🔄 FIFO vs LIFO - ¿Cuál usar?</h3>
                      <div className="space-y-4">
                        <div className="p-4 bg-green-100 rounded-lg border-2 border-green-300">
                          <h4 className="font-bold text-green-900 mb-2">✅ FIFO (First In, First Out) - RECOMENDADO</h4>
                          <p className="text-sm mb-2"><strong>Por qué es ideal para ExportAndes:</strong></p>
                          <ul className="text-sm space-y-1">
                            <li>• Productos perecederos (banano, rosas, atún) tienen vida útil limitada</li>
                            <li>• Requisitos fitosanitarios internacionales exigen frescura</li>
                            <li>• Control de fechas de cosecha y empaquetado</li>
                            <li>• Previene pérdidas por vencimiento</li>
                            <li>• Mejor para certificaciones orgánicas</li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-orange-100 rounded-lg">
                          <h4 className="font-bold text-orange-900 mb-2">⚠️ LIFO (Last In, First Out) - No recomendado</h4>
                          <p className="text-sm">Solo sería útil para productos no perecederos como artesanías, pero ExportAndes maneja principalmente productos frescos.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {tutorialStep === 3 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-purple-800">🏗️ Criterios de Diseño Funcional</h3>
                      <div className="space-y-3">
                        <div className="p-3 bg-purple-100 rounded-lg">
                          <h4 className="font-bold text-purple-900 mb-1">🎯 Funcionalidad del Diseño</h4>
                          <p className="text-sm">Uso eficiente del espacio para operaciones diarias y productividad</p>
                        </div>
                        <div className="p-3 bg-blue-100 rounded-lg">
                          <h4 className="font-bold text-blue-900 mb-1">♿ Accesibilidad Garantizada</h4>
                          <p className="text-sm">Acceso fácil sin obstáculos para personal y equipos</p>
                        </div>
                        <div className="p-3 bg-red-100 rounded-lg">
                          <h4 className="font-bold text-red-900 mb-1">🛡️ Seguridad en el Diseño</h4>
                          <p className="text-sm">Protección de personal y cumplimiento de normativas</p>
                        </div>
                        <div className="p-3 bg-green-100 rounded-lg">
                          <h4 className="font-bold text-green-900 mb-1">🔄 Adaptabilidad del Layout</h4>
                          <p className="text-sm">Incorporación de nuevas tecnologías sin interrupciones</p>
                        </div>
                        <div className="p-3 bg-yellow-100 rounded-lg">
                          <h4 className="font-bold text-yellow-900 mb-1">📈 Facilidad para Ampliaciones</h4>
                          <p className="text-sm">Expansión sin afectar operatividad existente</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {tutorialStep === 4 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-indigo-50 to-cyan-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-indigo-800">🚚 Optimización de Flujo y Rutas</h3>
                      <div className="space-y-3">
                        <div className="p-3 bg-indigo-100 rounded-lg">
                          <h4 className="font-bold text-indigo-900 mb-1">📦 Manejo Eficiente de Mercancías</h4>
                          <p className="text-sm">Optimización del flujo y almacenamiento para acelerar procesos</p>
                        </div>
                        <div className="p-3 bg-cyan-100 rounded-lg">
                          <h4 className="font-bold text-cyan-900 mb-1">🏃‍♂️ Agilidad en Procesos</h4>
                          <p className="text-sm">Manipulación rápida para satisfacer demandas internacionales</p>
                        </div>
                        <div className="p-3 bg-emerald-100 rounded-lg">
                          <h4 className="font-bold text-emerald-900 mb-1">💰 Apoyo a Rentabilidad</h4>
                          <p className="text-sm">Diseño adecuado reduce costos y aumenta rentabilidad</p>
                        </div>
                        <div className="p-3 bg-amber-100 rounded-lg">
                          <h4 className="font-bold text-amber-900 mb-1">🗺️ Diseño de Rutas Lógicas</h4>
                          <p className="text-sm">Rutas claras y definidas para flujo eficiente</p>
                        </div>
                        <div className="p-3 bg-rose-100 rounded-lg">
                          <h4 className="font-bold text-rose-900 mb-1">🚫 Prevención de Congestiones</h4>
                          <p className="text-sm">Evitar puntos de congestión para mejorar productividad</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setTutorialStep(Math.max(0, tutorialStep - 1))}
                    disabled={tutorialStep === 0}
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Anterior
                  </Button>
                  
                  <div className="flex gap-2">
                    {[0, 1, 2, 3, 4].map((step) => (
                      <div
                        key={step}
                        className={`w-2 h-2 rounded-full ${
                          step === tutorialStep ? 'bg-blue-500' : 'bg-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  
                  {tutorialStep < 4 ? (
                    <Button onClick={() => setTutorialStep(tutorialStep + 1)}>
                      Siguiente
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setShowTutorial(false)
                          setShowStory(true)
                          setStoryStep(0)
                        }}
                      >
                        Comenzar Desafío
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Story Modal */}
        {showStory && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <BookOpen className="w-6 h-6" />
                  Tu Desafío Comienza: Supermercado "El Buen Sabor"
                </CardTitle>
                <CardDescription>
                  Toma decisiones críticas que afectarán el éxito del negocio
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {storyStep === 0 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-orange-800">🏪 El Contexto</h3>
                      <div className="space-y-3 text-sm">
                        <p>
                          <strong>Eres el nuevo Gerente de Operaciones</strong> de "El Buen Sabor", 
                          una cadena de supermercados en crecimiento con 5 tiendas en Quito y Cumbayá.
                        </p>
                        <p>
                          <strong>El Problema:</strong> El mes pasado, el supermercado perdió $45,000 
                          en productos vencidos y clientes quejándose por falta de frescura. 
                          El dueño, Don Carlos, te ha dado 30 días para solucionar el problema.
                        </p>
                        <p>
                          <strong>Tu Misión:</strong> Diseñar y gestionar el nuevo centro de distribución 
                          que abastecerá a todas las tiendas. Tu decisión sobre el método de inventario 
                          será CRUCIAL para el éxito o fracaso del negocio.
                        </p>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <h4 className="font-bold mb-2 text-red-800">⚠️ La Presión es Real:</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm text-red-700">
                        <li>Don Carlos ha amenazado con despedirte si no mejoras las operaciones</li>
                        <li>Los proveedores están presionando por pagos de productos vencidos</li>
                        <li>Los clientes están cambiando a la competencia</li>
                        <li>El banco está evaluando cancelar tu línea de crédito</li>
                      </ul>
                    </div>
                  </div>
                )}

                {storyStep === 1 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-blue-800">📦 Los Productos que Manejarás</h3>
                      <div className="space-y-4">
                        <div className="p-4 bg-red-100 rounded-lg">
                          <h4 className="font-bold text-red-900 mb-2">🚨 ALTA ROTACIÓN - Productos Perecederos</h4>
                          <p className="text-sm mb-2">Estos productos vencen en 3-7 días:</p>
                          <ul className="text-sm space-y-1">
                            <li>• Fresas Frescas Orgánicas - $4.50/unidad</li>
                            <li>• Leche Fresca Pasteurizada - $1.20/unidad</li>
                            <li>• Yogurt Natural - $2.80/unidad</li>
                            <li>• Pan Integral Fresco - $3.50/unidad</li>
                            <li>• Huevos Orgánicos - $0.50/unidad</li>
                            <li>• Tomates Frescos - $2.20/unidad</li>
                            <li>• Pollo Fresco - $5.80/unidad</li>
                            <li>• Pescado Fresco - $8.90/unidad</li>
                          </ul>
                          <p className="text-xs mt-2 text-red-700 font-medium">
                            💡 Estos productos representan 60% de tus ventas pero 80% de tus pérdidas por vencimiento
                          </p>
                        </div>
                        
                        <div className="p-4 bg-yellow-100 rounded-lg">
                          <h4 className="font-bold text-yellow-900 mb-2">⚡ MEDIA ROTACIÓN - Semi-perecederos</h4>
                          <p className="text-sm mb-2">Duración de 2-4 semanas:</p>
                          <ul className="text-sm space-y-1">
                            <li>• Arroz Blanco Grano Largo - $1.80/unidad</li>
                            <li>• Pasta Italiana - $2.50/unidad</li>
                            <li>• Aceite de Oliva Extra Virgen - $12.00/unidad</li>
                            <li>• Cereal Integral - $4.20/unidad</li>
                            <li>• Galletas Integrales - $2.80/unidad</li>
                            <li>• Mermelada Artesanal - $5.50/unidad</li>
                            <li>• Café en Grano Tostado - $8.20/unidad</li>
                            <li>• Té Verde Orgánico - $6.80/unidad</li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-gray-100 rounded-lg">
                          <h4 className="font-bold text-gray-900 mb-2">📦 BAJA ROTACIÓN - No perecederos</h4>
                          <p className="text-sm mb-2">Duración de 6-12 meses:</p>
                          <ul className="text-sm space-y-1">
                            <li>• Sal Marina Refinada - $1.20/unidad</li>
                            <li>• Azúcar Blanca - $1.50/unidad</li>
                            <li>• Harina de Trigo - $2.20/unidad</li>
                            <li>• Vinagre de Manzana - $3.80/unidad</li>
                            <li>• Especias Variadas - $15.00/unidad</li>
                            <li>• Conservas Vegetales - $4.50/unidad</li>
                            <li>• Aceite Vegetal - $3.20/unidad</li>
                            <li>• Chocolate en Polvo - $7.50/unidad</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {storyStep === 2 && (
                  <div className="space-y-4">
                    <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border">
                      <h3 className="text-xl font-bold mb-4 text-green-800">🤔 Tu Decisión Crítica</h3>
                      <div className="space-y-4">
                        <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                          <h4 className="font-bold text-blue-900 mb-3">El Dilema de Don Carlos:</h4>
                          <p className="text-sm mb-3">
                            "Gerente, he estado investigando y hay dos métodos principales de gestión de inventario. 
                            Necesito que elijas el correcto, porque esta decisión determinará si salvamos o quebramos el negocio."
                          </p>
                          <p className="text-sm font-medium text-blue-800">
                            Los proveedores están esperando tu decisión para empezar a enviar productos mañana...
                          </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-4 bg-green-100 rounded-lg border-2 border-green-300 cursor-pointer hover:bg-green-200 transition-colors"
                               onClick={() => setSelectedMethod('FIFO')}>
                            <h4 className="font-bold text-green-900 mb-2">✅ FIFO (First In, First Out)</h4>
                            <ul className="text-sm space-y-1">
                              <li>• Lo primero que entra es lo primero que sale</li>
                              <li>• Ideal para productos perecederos</li>
                              <li>• Previene vencimientos</li>
                              <li>• Clientes siempre reciben productos frescos</li>
                              <li>• Requiere control de fechas estricto</li>
                            </ul>
                            <p className="text-xs mt-2 text-green-700 font-medium">
                              💡 Recomendado para productos frescos
                            </p>
                          </div>
                          
                          <div className="p-4 bg-orange-100 rounded-lg border-2 border-orange-300 cursor-pointer hover:bg-orange-200 transition-colors"
                               onClick={() => setSelectedMethod('LIFO')}>
                            <h4 className="font-bold text-orange-900 mb-2">⚠️ LIFO (Last In, First Out)</h4>
                            <ul className="text-sm space-y-1">
                              <li>• Lo último que entra es lo primero que sale</li>
                              <li>• Bueno para productos no perecederos</li>
                              <li>• Puede causar vencimientos en productos frescos</li>
                              <li>• Más simple administrativamente</li>
                              <li>• Riesgoso para tu situación actual</li>
                            </ul>
                            <p className="text-xs mt-2 text-orange-700 font-medium">
                              ⚠️ Peligroso para productos perecederos
                            </p>
                          </div>
                        </div>

                        {selectedMethod && (
                          <div className={`p-4 rounded-lg border-2 ${
                            selectedMethod === 'FIFO' 
                              ? 'bg-blue-100 border-blue-400' 
                              : 'bg-blue-100 border-blue-400'
                          }`}>
                            <p className="text-sm font-medium text-blue-800">
                              Has seleccionado {selectedMethod}. Esta decisión afectará tus operaciones.
                              Descubrirás las consecuencias durante la simulación.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setStoryStep(Math.max(0, storyStep - 1))}
                    disabled={storyStep === 0}
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Anterior
                  </Button>
                  
                  <div className="flex gap-2">
                    {[0, 1, 2].map((step) => (
                      <div
                        key={step}
                        className={`w-2 h-2 rounded-full ${
                          step === storyStep ? 'bg-blue-500' : 'bg-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  
                  {storyStep < 2 ? (
                    <Button onClick={() => setStoryStep(storyStep + 1)}>
                      Siguiente
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => {
                        if (selectedMethod) {
                          setGameState(prev => ({ ...prev, inventoryMethod: selectedMethod }))
                          setShowStory(false)
                          setShowInventory(true)
                        } else {
                          alert('Debes seleccionar un método de inventario para continuar')
                        }
                      }}
                      disabled={!selectedMethod}
                    >
                      Ver Inventario Detallado
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Inventory Modal */}
        {showInventory && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="max-w-6xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Package className="w-6 h-6" />
                  Tu Inventario - Clasificación ABC Completa
                </CardTitle>
                <CardDescription>
                  Método seleccionado: <span className="font-bold text-blue-600">{selectedMethod}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Category A */}
                  <div className="space-y-3">
                    <div className="p-4 bg-red-100 rounded-lg border-2 border-red-300">
                      <h3 className="font-bold text-red-900 mb-2">🔥 Categoría A - Alta Rotación</h3>
                      <p className="text-sm text-red-700 mb-3">20% productos, 80% valor - ¡CRÍTICO!</p>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {userProducts.filter(p => p.category === 'A').map(product => (
                          <div key={product.id} className="p-2 bg-white rounded border text-xs">
                            <div className="font-medium">{product.name}</div>
                            <div className="text-gray-600">
                              ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}
                            </div>
                            <div className="text-red-600 font-medium mb-2">
                              📅 Vence: {product.entryDate.getDate() + 3}/{product.entryDate.getMonth() + 1}
                            </div>
                            <div className="flex gap-1">
                              <button
                                onClick={() => updateProductRotation(product.id, 'high')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'high' 
                                    ? 'bg-red-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-red-200'
                                }`}
                              >
                                Alta
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'medium')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'medium' 
                                    ? 'bg-yellow-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-yellow-200'
                                }`}
                              >
                                Media
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'low')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'low' 
                                    ? 'bg-gray-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                Baja
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 p-2 bg-red-50 rounded text-sm font-medium text-red-800">
                        Total Categoría A: ${userProducts.filter(p => p.category === 'A').reduce((sum, p) => sum + (p.unitValue * p.quantity), 0).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Category B */}
                  <div className="space-y-3">
                    <div className="p-4 bg-yellow-100 rounded-lg border-2 border-yellow-300">
                      <h3 className="font-bold text-yellow-900 mb-2">⚡ Categoría B - Media Rotación</h3>
                      <p className="text-sm text-yellow-700 mb-3">30% productos, 15% valor - Importante</p>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {userProducts.filter(p => p.category === 'B').map(product => (
                          <div key={product.id} className="p-2 bg-white rounded border text-xs">
                            <div className="font-medium">{product.name}</div>
                            <div className="text-gray-600">
                              ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}
                            </div>
                            <div className="text-yellow-600 font-medium mb-2">
                              📅 Vence: {product.entryDate.getDate() + 14}/{product.entryDate.getMonth() + 1}
                            </div>
                            <div className="flex gap-1">
                              <button
                                onClick={() => updateProductRotation(product.id, 'high')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'high' 
                                    ? 'bg-red-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-red-200'
                                }`}
                              >
                                Alta
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'medium')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'medium' 
                                    ? 'bg-yellow-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-yellow-200'
                                }`}
                              >
                                Media
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'low')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'low' 
                                    ? 'bg-gray-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                Baja
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 p-2 bg-yellow-50 rounded text-sm font-medium text-yellow-800">
                        Total Categoría B: ${userProducts.filter(p => p.category === 'B').reduce((sum, p) => sum + (p.unitValue * p.quantity), 0).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Category C */}
                  <div className="space-y-3">
                    <div className="p-4 bg-gray-100 rounded-lg border-2 border-gray-300">
                      <h3 className="font-bold text-gray-900 mb-2">📦 Categoría C - Baja Rotación</h3>
                      <p className="text-sm text-gray-700 mb-3">50% productos, 5% valor - Estable</p>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {userProducts.filter(p => p.category === 'C').map(product => (
                          <div key={product.id} className="p-2 bg-white rounded border text-xs">
                            <div className="font-medium">{product.name}</div>
                            <div className="text-gray-600">
                              ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}
                            </div>
                            <div className="text-green-600 font-medium mb-2">
                              📅 Vence: {product.entryDate.getDate() + 180}/{product.entryDate.getMonth() + 1}
                            </div>
                            <div className="flex gap-1">
                              <button
                                onClick={() => updateProductRotation(product.id, 'high')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'high' 
                                    ? 'bg-red-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-red-200'
                                }`}
                              >
                                Alta
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'medium')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'medium' 
                                    ? 'bg-yellow-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-yellow-200'
                                }`}
                              >
                                Media
                              </button>
                              <button
                                onClick={() => updateProductRotation(product.id, 'low')}
                                className={`px-2 py-1 text-xs rounded ${
                                  product.rotationSpeed === 'low' 
                                    ? 'bg-gray-500 text-white' 
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                Baja
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 p-2 bg-gray-50 rounded text-sm font-medium text-gray-800">
                        Total Categoría C: ${userProducts.filter(p => p.category === 'C').reduce((sum, p) => sum + (p.unitValue * p.quantity), 0).toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-bold mb-2 text-blue-800">📊 Clasificación de Rotación</h4>
                  <p className="text-sm text-blue-700 mb-2">
                    Clasifica cada producto según su velocidad de rotación. Esta decisión afectará la evaluación de tu layout:
                  </p>
                  <ul className="text-sm space-y-1 text-blue-700">
                    <li>• <strong>Alta Rotación:</strong> Productos que se venden rápidamente (diario/semanal)</li>
                    <li>• <strong>Media Rotación:</strong> Productos con venta moderada (quincenal/mensual)</li>
                    <li>• <strong>Baja Rotación:</strong> Productos que se mueven lentamente (trimestral/anual)</li>
                  </ul>
                </div>

                <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
                  <h3 className="font-bold mb-3 text-blue-800">🎯 Tu Misión de Diseño</h3>
                  <div className="space-y-3 text-sm">
                    <p><strong>1. Diseña el Layout Perfecto:</strong></p>
                    <ul className="ml-4 space-y-1">
                      <li>• Productos A (perecederos) cerca de despacho para salida rápida</li>
                      <li>• Productos B en zonas intermedias de fácil acceso</li>
                      <li>• Productos C en zonas lejanas (se mueven poco)</li>
                      <li>• Recepción separada de despacho para evitar cruces</li>
                    </ul>
                    
                    <p><strong>2. Optimiza el Flujo con {selectedMethod}:</strong></p>
                    <ul className="ml-4 space-y-1">
                      <li>• {selectedMethod === 'FIFO' ? 'Los productos más antiguos deben salir primero' : 'Los productos más nuevos deben salir primero'}</li>
                      <li>• Control estricto de fechas de vencimiento</li>
                      <li>• Rutas eficientes para minimizar tiempo de manipulación</li>
                    </ul>
                    
                    <p><strong>3. Logra los Objetivos:</strong></p>
                    <ul className="ml-4 space-y-1">
                      <li>• Eficiencia mínima: 40%</li>
                      <li>• Presupuesto máximo: $120,000</li>
                      <li>• Distancia máxima de recorrido: 50 unidades</li>
                      <li>• Cero pérdidas por vencimiento</li>
                    </ul>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button 
                    onClick={startUserChallenge}
                    size="lg"
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Package className="w-5 h-5 mr-2" />
                    Comenzar Diseño del Layout
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Example Modal */}
        {showExample && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="max-w-6xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Play className="w-6 h-6" />
                  Ejemplo Práctico: Layout Optimizado para ExportAndes
                </CardTitle>
                <CardDescription>
                  Observa el flujo de productos y el diseño eficiente
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Example Grid */}
                  <div>
                    <h3 className="font-bold mb-3">Layout de Ejemplo (10x10)</h3>
                    <div className="grid grid-cols-10 gap-1 p-4 bg-gray-50 rounded-lg">
                      {exampleLayout.map((row, rowIndex) =>
                        row.map((product, colIndex) => {
                          const isInFlow = flowPath.some(fp => fp.row === rowIndex && fp.col === colIndex)
                          const isReceiving = rowIndex === 0 && colIndex < 2
                          const isPicking = rowIndex === 5 && colIndex === 4
                          const isShipping = rowIndex === 9 && colIndex === 9
                          
                          return (
                            <div
                              key={`${rowIndex}-${colIndex}`}
                              className={`w-8 h-8 border rounded flex items-center justify-center text-xs font-bold
                                ${isReceiving ? 'bg-blue-500 text-white' : ''}
                                ${isPicking ? 'bg-purple-500 text-white' : ''}
                                ${isShipping ? 'bg-orange-500 text-white' : ''}
                                ${product?.category === 'A' && !isReceiving && !isPicking && !isShipping ? 'bg-red-500 text-white' : ''}
                                ${product?.category === 'B' && !isReceiving && !isPicking && !isShipping ? 'bg-yellow-500 text-white' : ''}
                                ${product?.category === 'C' && !isReceiving && !isPicking && !isShipping ? 'bg-gray-500 text-white' : ''}
                                ${!product && !isReceiving && !isPicking && !isShipping ? 'bg-gray-100' : ''}
                                ${isInFlow ? 'ring-2 ring-green-400 ring-offset-1' : ''}
                              `}
                            >
                              {product?.category || (isReceiving ? 'R' : isPicking ? 'P' : isShipping ? 'S' : '')}
                            </div>
                          )
                        })
                      )}
                    </div>
                    
                    <div className="flex gap-2 mt-4">
                      <Button 
                        onClick={runExampleFlow}
                        disabled={isRunningExample}
                        className="flex-1"
                      >
                        {isRunningExample ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Simulando...
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Simular Flujo
                          </>
                        )}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setShowExample(false)}
                      >
                        Cerrar Ejemplo
                      </Button>
                    </div>
                  </div>

                  {/* Flow Information */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold mb-3">Flujo Actual</h3>
                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg min-h-[200px]">
                        {isRunningExample ? (
                          <div className="space-y-2">
                            <p className="font-medium text-green-800">Paso {currentFlowStep + 1}:</p>
                            <p className="text-sm text-green-700">
                              {flowPath[0]?.description || 'Preparando simulación...'}
                            </p>
                            {flowPath[0]?.product && (
                              <div className="p-2 bg-white rounded border">
                                <p className="text-xs font-medium">Producto: {flowPath[0].product.name}</p>
                                <p className="text-xs">Categoría: {flowPath[0].product.category}</p>
                                <p className="text-xs">Valor: ${flowPath[0].product.unitValue}</p>
                              </div>
                            )}
                          </div>
                        ) : (
                          <p className="text-sm text-gray-600">
                            Haz clic en "Simular Flujo" para ver cómo se mueven los productos 
                            a través del layout optimizado de ExportAndes.
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-bold mb-3">Leyenda</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-blue-500 rounded"></div>
                          <span>Recepción</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-red-500 rounded"></div>
                          <span>Productos A (Alta rotación)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                          <span>Productos B (Media rotación)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-gray-500 rounded"></div>
                          <span>Productos C (Baja rotación)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-purple-500 rounded"></div>
                          <span>Picking</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-orange-500 rounded"></div>
                          <span>Despacho</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-green-400 rounded ring-2 ring-green-400 ring-offset-1"></div>
                          <span>Flujo activo</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-bold mb-2 text-blue-800">💡 Características del Layout:</h4>
                      <ul className="text-sm space-y-1 text-blue-700">
                        <li>• Productos A cerca de picking para acceso rápido</li>
                        <li>• Productos C en zonas periféricas (baja rotación)</li>
                        <li>• Ruta lógica: Recepción → Almacenaje → Picking → Despacho</li>
                        <li>• Zonas de temperatura controlada para productos frescos</li>
                        <li>• Espacio para equipos de manejo de materiales</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button 
                    onClick={() => {
                      setShowExample(false)
                      setShowExplanation(false)
                    }}
                    size="lg"
                  >
                    Comenzar Mi Propio Diseño
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Header */}
        <div className="mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 mb-2">
                Simulador de Layout de Bodega con Gestión ABC
              </h1>
              <p className="text-slate-600">
                {currentLevel.description}
              </p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setShowTutorial(true)
                  setTutorialStep(0)
                }}
              >
                <GraduationCap className="w-4 h-4 mr-2" />
                Tutorial
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setShowStory(true)
                  setStoryStep(0)
                  setSelectedMethod(null)
                }}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Historia
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowExample(true)}
              >
                <Play className="w-4 h-4 mr-2" />
                Ejemplo
              </Button>
              {gameState.resetPenalty > 0 && (
                <Badge variant="destructive" className="text-lg px-3 py-1">
                  <RefreshCw className="w-4 h-4 mr-1" />
                  -{gameState.resetPenalty} pts
                </Badge>
              )}
              <Badge variant="outline" className="text-lg px-3 py-1">
                <Trophy className="w-4 h-4 mr-1" />
                {gameState.score} pts
              </Badge>
              <Badge variant="outline" className="text-lg px-3 py-1">
                Nivel {gameState.currentLevel}/{LEVELS.length}
              </Badge>
              <Badge variant="outline" className="text-lg px-3 py-1">
                <Filter className="w-4 h-4 mr-1" />
                {gameState.inventoryMethod}
              </Badge>
            </div>
          </div>
        </div>

        {/* Tutorial y Explicaciones */}
        {showExplanation && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-3">
                <div>
                  <p className="font-medium mb-2">🎯 <strong>Objetivo:</strong> {currentLevel.objective}</p>
                  <p className="font-medium mb-1">📋 <strong>Restricciones:</strong></p>
                  <ul className="ml-4 space-y-1 text-sm">
                    {currentLevel.constraints.map((constraint, index) => (
                      <li key={index}>• {constraint}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-white p-3 rounded border border-blue-200">
                  <p className="font-medium mb-2 text-blue-800">📚 <strong>Conceptos Avanzados:</strong></p>
                  <div className="space-y-2 text-sm text-blue-700">
                    <div>
                      <strong>🏷️ Clasificación ABC:</strong> Método que categoriza productos según su valor. 
                      A (80% valor, 20% cantidad), B (15% valor, 30% cantidad), C (5% valor, 50% cantidad).
                    </div>
                    <div>
                      <strong>🔄 Rotación de Inventario:</strong> Velocidad con que los productos se venden y reponen. 
                      Alta rotación = movimiento rápido, debe estar accesible.
                    </div>
                    <div>
                      <strong>📦 FIFO/LIFO:</strong> Métodos de gestión. 
                      FIFO (First In, First Out) para productos perecederos, 
                      LIFO (Last In, First Out) para productos no perecederos.
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={() => setShowExplanation(false)} 
                  size="sm" 
                  className="mt-2"
                >
                  ¡Entendido! Comenzar a diseñar
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Tabs de navegación */}
        <div className="mb-6">
          <div className="flex gap-2 p-1 bg-slate-100 rounded-lg w-fit">
            <Button
              variant={activeTab === 'layout' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('layout')}
            >
              <Warehouse className="w-4 h-4 mr-2" />
              Layout
            </Button>
            <Button
              variant={activeTab === 'inventory' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('inventory')}
            >
              <Package className="w-4 h-4 mr-2" />
              Inventario ABC
            </Button>
            <Button
              variant={activeTab === 'analysis' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('analysis')}
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Análisis
            </Button>
          </div>
        </div>

        {/* Panel de Estado */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-500" />
                <div>
                  <div className="text-sm text-slate-600">Objetivo</div>
                  <div className="font-bold">{currentLevel.targetEfficiency}%</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Move className="w-5 h-5 text-green-500" />
                <div>
                  <div className="text-sm text-slate-600">Distancia Máx</div>
                  <div className="font-bold">{currentLevel.maxDistance}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-purple-500" />
                <div>
                  <div className="text-sm text-slate-600">Presupuesto</div>
                  <div className="font-bold text-xs">
                    ${gameState.usedBudget.toLocaleString()}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-red-500" />
                <div>
                  <div className="text-sm text-slate-600">Productos</div>
                  <div className="font-bold">{gameState.products.length}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-orange-500" />
                <div>
                  <div className="text-sm text-slate-600">Intentos</div>
                  <div className="font-bold">{gameState.attempts}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contenido principal según tab */}
        {activeTab === 'layout' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Panel de Control */}
            <div className="lg:col-span-1 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-5 h-5" />
                    Zonas ABC
                  </CardTitle>
                  <CardDescription>
                    Selecciona y coloca zonas especializadas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {currentLevel.requiredZones.map((zone) => (
                    <div key={zone} className="space-y-2">
                      <Button
                        variant={selectedZone === zone ? "default" : "outline"}
                        className="w-full justify-start"
                        onClick={() => setSelectedZone(zone)}
                        disabled={gameState.isComplete}
                      >
                        <div className={`w-4 h-4 rounded ${ZONE_COLORS[zone].split(' ')[0]} mr-2`} />
                        {ZONE_ICONS[zone]}
                        <span className="ml-2 text-sm">{ZONE_LABELS[zone]}</span>
                        <Badge variant="secondary" className="ml-auto text-xs">
                          ${currentLevel.zoneCosts[zone].toLocaleString()}
                        </Badge>
                      </Button>
                      <div className="text-xs text-slate-500 px-2">
                        Colocadas: {gameState.placedZones[zone]}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Método de Inventario</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <div className="text-lg font-medium text-center mb-2">
                      {gameState.inventoryMethod}
                    </div>
                    <div className="text-xs text-slate-600 text-center">
                      {gameState.inventoryMethod === 'FIFO' ? 
                        'First In, First Out - Ideal para perecederos' : 
                        'Last In, First Out - Para productos no perecederos'
                      }
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Acciones</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={runSimulation} 
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={isSimulating || gameState.isComplete}
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    {isSimulating ? 'Ejecutando Simulación...' : 'Ejecutar Simulación Completa'}
                  </Button>
                  <Button 
                    onClick={resetLevel} 
                    variant="outline" 
                    className="w-full"
                    disabled={isSimulating}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Reiniciar
                  </Button>
                </CardContent>
              </Card>

              {/* Progreso del Presupuesto */}
              <Card>
                <CardHeader>
                  <CardTitle>Análisis de Presupuesto</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress 
                    value={(gameState.usedBudget / currentLevel.budget) * 100} 
                    className="w-full mb-2"
                  />
                  <div className="flex justify-between text-sm">
                    <span>${gameState.usedBudget.toLocaleString()}</span>
                    <span>${currentLevel.budget.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Grid del Almacén */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Warehouse className="w-5 h-5" />
                    Layout ABC del Almacén
                    {isSimulating && (
                      <Badge variant="secondary" className="ml-auto">
                        <Activity className="w-3 h-3 mr-1" />
                        Simulando...
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>
                    Cuadrícula {currentLevel.gridSize}x{currentLevel.gridSize} - Zonas ABC especializadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="inline-block bg-white p-4 rounded-lg border">
                    {/* Coordenadas horizontales (números) */}
                    <div className="flex" style={{ marginLeft: '30px' }}>
                      {Array.from({ length: currentLevel.gridSize }, (_, i) => (
                        <div key={i} className="w-10 h-6 flex items-center justify-center text-xs font-bold text-gray-600">
                          {i + 1}
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex">
                      {/* Coordenadas verticales (letras) */}
                      <div className="flex flex-col">
                        <div className="w-8 h-6"></div> {/* Espacio vacío para alinear */}
                        {Array.from({ length: currentLevel.gridSize }, (_, i) => (
                          <div key={i} className="w-8 h-10 flex items-center justify-center text-xs font-bold text-gray-600">
                            {String.fromCharCode(65 + i)}
                          </div>
                        ))}
                      </div>
                      
                      {/* Grid principal */}
                      <div 
                        className="grid gap-0 border-2 border-slate-300"
                        style={{ 
                          gridTemplateColumns: `repeat(${currentLevel.gridSize}, 40px)`,
                          gridTemplateRows: `repeat(${currentLevel.gridSize}, 40px)`
                        }}
                      >
                        {grid.map((row, rowIndex) =>
                          row.map((cell, colIndex) => (
                            <div
                              key={`${rowIndex}-${colIndex}`}
                              className={`border border-slate-200 cursor-pointer transition-all flex items-center justify-center text-white relative text-xs
                                ${ZONE_COLORS[cell.zone]}
                                ${selectedZone === cell.zone && !gameState.isComplete ? 'ring-2 ring-offset-1 ring-blue-500' : ''}
                                ${gameState.isComplete ? 'cursor-not-allowed' : ''}
                              `}
                              style={{ width: 40, height: 40 }}
                              onClick={() => handleCellClick(rowIndex, colIndex)}
                              title={`Coordenada: ${String.fromCharCode(65 + rowIndex)}${colIndex + 1}`}
                            >
                              {cell.zone !== 'empty' && ZONE_ICONS[cell.zone]}
                              {cell.productType && (
                                <div className="absolute top-0 right-0 text-xs font-bold">
                                  {cell.productType}
                                </div>
                              )}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Leyenda ABC */}
                  <div className="mt-4 space-y-2">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-red-500" />
                        Zona A (Alta Rotación)
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-yellow-500" />
                        Zona B (Media Rotación)
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-gray-500" />
                        Zona C (Baja Rotación)
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {gameState.isComplete && (
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <Trophy className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-green-800 mb-2">¡Nivel Completado!</h3>
                      <p className="text-green-700">
                        Has completado el nivel con {calculateEfficiency().toFixed(1)}% de eficiencia.
                        Puntos ganados: +{Math.floor(calculateEfficiency() * 10)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* Tab de Inventario */}
        {activeTab === 'inventory' && (
          <InventoryAnalysis 
            products={gameState.products} 
            inventoryMethod={gameState.inventoryMethod.toLowerCase() as 'fifo' | 'lifo'}
            isSimulationComplete={gameState.isComplete}
            onDecisionsLocked={(decisions) => {
              console.log('Decisiones bloqueadas:', decisions)
            }}
          />
        )}

        {/* Tab de Análisis */}
        {activeTab === 'analysis' && (
          <AnalysisResults 
            simulationResult={gameState.simulationResult || null}
            warehouseGrid={getWarehouseGrid()}
            inventoryMethod={gameState.inventoryMethod.toLowerCase() as 'fifo' | 'lifo'}
            products={gameState.products}
          />
        )}
      </div>
    </div>
  )
}