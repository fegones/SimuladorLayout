'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Product } from '@/app/page'
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Target,
  DollarSign,
  Package,
  ArrowRight
} from 'lucide-react'

interface SimulationResult {
  score: number
  efficiency: number
  inventoryMethodScore: number
  budgetScore: number
  recommendations: string[]
  details: {
    layoutEfficiency: number
    inventoryCompatibility: number
    budgetUsage: number
    totalDistance: number
    abcCompliance: number
  }
}

interface AnalysisResultsProps {
  simulationResult: SimulationResult | null
  warehouseGrid: Record<string, Product>
  inventoryMethod: 'fifo' | 'lifo'
  products: Product[]
}

export default function AnalysisResults({ 
  simulationResult, 
  warehouseGrid, 
  inventoryMethod, 
  products 
}: AnalysisResultsProps) {
  if (!simulationResult) {
    return (
      <div className="text-center py-12">
        <Target className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-600 mb-2">Sin Resultados de Simulación</h3>
        <p className="text-slate-500 mb-6">
          Ejecuta una simulación desde la pestaña Layout para ver análisis detallados.
        </p>
        <Button onClick={() => window.location.href = '#layout'} variant="outline">
          Ir a Layout
        </Button>
      </div>
    )
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5 text-green-500" />
    if (score >= 60) return <AlertTriangle className="w-5 h-5 text-yellow-500" />
    return <XCircle className="w-5 h-5 text-red-500" />
  }

  const getScoreMessage = (score: number) => {
    if (score >= 90) return 'Excelente'
    if (score >= 80) return 'Muy Bueno'
    if (score >= 70) return 'Bueno'
    if (score >= 60) return 'Regular'
    if (score >= 50) return 'Necesita Mejoras'
    return 'Crítico'
  }

  // Análisis adicional del layout actual
  const placedProducts = Object.values(warehouseGrid)
  const placedCategories = {
    A: placedProducts.filter(p => p.category === 'A').length,
    B: placedProducts.filter(p => p.category === 'B').length,
    C: placedProducts.filter(p => p.category === 'C').length
  }

  const totalPlacedValue = placedProducts.reduce((sum, p) => sum + (p.unitValue * p.quantity), 0)
  const perishableInWarehouse = placedProducts.filter(p => p.isPerishable).length

  return (
    <div className="space-y-6">
      {/* Score Principal */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Target className="w-6 h-6" />
              Resultado de la Simulación
            </span>
            <div className={`text-3xl font-bold ${getScoreColor(simulationResult.score)}`}>
              {simulationResult.score}/100
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div className={`text-lg font-medium ${getScoreColor(simulationResult.score)}`}>
              {getScoreMessage(simulationResult.score)}
            </div>
            <p className="text-slate-600 mt-2">
              Evaluación completa del diseño de tu almacén
            </p>
          </div>

          {/* Métricas Principales */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {simulationResult.details.layoutEfficiency}%
              </div>
              <div className="text-sm text-slate-600">Eficiencia Layout</div>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {simulationResult.details.inventoryCompatibility}%
              </div>
              <div className="text-sm text-slate-600">Compatibilidad Método</div>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {simulationResult.details.budgetUsage}%
              </div>
              <div className="text-sm text-slate-600">Uso Presupuesto</div>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {simulationResult.details.abcCompliance}%
              </div>
              <div className="text-sm text-slate-600">Cumplimiento ABC</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Análisis Detallado */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Análisis de Layout */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Análisis de Layout
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Eficiencia del Diseño</span>
              <div className="flex items-center gap-2">
                {getScoreIcon(simulationResult.details.layoutEfficiency)}
                <span className={`font-medium ${getScoreColor(simulationResult.details.layoutEfficiency)}`}>
                  {simulationResult.details.layoutEfficiency}%
                </span>
              </div>
            </div>
            
            <div className="text-sm text-slate-600 space-y-2">
              <div>• Productos colocados: {Object.keys(warehouseGrid).length}</div>
              <div>• Valor total almacenado: ${totalPlacedValue.toFixed(2)}</div>
              <div>• Distancia total de desplazamiento: {simulationResult.details.totalDistance}</div>
              <div>• Productos perecederos en almacén: {perishableInWarehouse}</div>
            </div>

            <div className="p-3 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-sm mb-2">Distribución por Categoría:</h4>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span>Categoría A:</span>
                  <span className="font-medium text-red-600">{placedCategories.A} productos</span>
                </div>
                <div className="flex justify-between">
                  <span>Categoría B:</span>
                  <span className="font-medium text-yellow-600">{placedCategories.B} productos</span>
                </div>
                <div className="flex justify-between">
                  <span>Categoría C:</span>
                  <span className="font-medium text-gray-600">{placedCategories.C} productos</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Análisis de Método de Inventario */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {inventoryMethod === 'fifo' ? (
                <TrendingDown className="w-5 h-5 text-blue-500" />
              ) : (
                <TrendingUp className="w-5 h-5 text-purple-500" />
              )}
              Método: {inventoryMethod.toUpperCase()}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Compatibilidad</span>
              <div className="flex items-center gap-2">
                {getScoreIcon(simulationResult.details.inventoryCompatibility)}
                <span className={`font-medium ${getScoreColor(simulationResult.details.inventoryCompatibility)}`}>
                  {simulationResult.details.inventoryCompatibility}%
                </span>
              </div>
            </div>

            <div className="text-sm text-slate-600 space-y-2">
              <div>• Método seleccionado: {inventoryMethod.toUpperCase()}</div>
              <div>• Productos perecederos: {products.filter(p => p.isPerishable).length}</div>
              <div>• Alta rotación: {products.filter(p => p.rotationSpeed === 'high').length}</div>
              <div>• Baja rotación: {products.filter(p => p.rotationSpeed === 'low').length}</div>
            </div>

            <div className={`p-3 rounded-lg ${
              simulationResult.details.inventoryCompatibility >= 70 
                ? 'bg-green-50' 
                : 'bg-yellow-50'
            }`}>
              <h4 className="font-medium text-sm mb-2">Análisis de Compatibilidad:</h4>
              <p className="text-sm">
                {inventoryMethod === 'fifo' 
                  ? simulationResult.details.inventoryCompatibility >= 70
                    ? 'FIFO es adecuado para tu inventario, especialmente con productos perecederos.'
                    : 'Considera revisar si FIFO es óptimo para tus productos no perecederos.'
                  : simulationResult.details.inventoryCompatibility >= 70
                    ? 'LIFO funciona bien con tu tipo de productos estables.'
                    : 'LIFO puede no ser ideal para productos perecederos o de alta rotación.'
                }
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recomendaciones Detalladas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Recomendaciones Específicas
          </CardTitle>
        </CardHeader>
        <CardContent>
          {simulationResult.recommendations.length > 0 ? (
            <div className="space-y-3">
              {simulationResult.recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                  <ArrowRight className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-slate-700">{recommendation}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
              <p className="text-green-700 font-medium">¡Excelente diseño!</p>
              <p className="text-sm text-slate-600">No hay recomendaciones específicas en este momento.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Análisis Presupuestario */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-500" />
            Análisis Presupuestario
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {simulationResult.details.budgetUsage}%
              </div>
              <div className="text-sm text-slate-600">Presupuesto Utilizado</div>
              <div className="text-xs text-slate-500 mt-1">
                {simulationResult.details.budgetUsage <= 80 
                  ? '✓ Uso eficiente' 
                  : simulationResult.details.budgetUsage <= 95 
                    ? '⚠️ Cerca del límite'
                    : '⚠️ Excede presupuesto'
                }
              </div>
            </div>
            
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {Object.keys(warehouseGrid).length}
              </div>
              <div className="text-sm text-slate-600">Casillas Ocupadas</div>
              <div className="text-xs text-slate-500 mt-1">
                de 100 disponibles
              </div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                ${totalPlacedValue.toFixed(0)}
              </div>
              <div className="text-sm text-slate-600">Valor Almacenado</div>
              <div className="text-xs text-slate-500 mt-1">
                {placedProducts.length} productos
              </div>
            </div>
          </div>

          {simulationResult.details.budgetUsage > 100 && (
            <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
              <h4 className="font-medium text-red-800 mb-2">⚠️ Advertencia de Presupuesto</h4>
              <p className="text-sm text-red-700">
                Has excedido el presupuesto disponible. Considera optimizar el layout o reducir costos.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Acciones Sugeridas */}
      <Card>
        <CardHeader>
          <CardTitle>🎯 Próximos Pasos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium">Si el score es bajo (&lt;60):</h4>
              <ul className="text-sm space-y-1 text-slate-600">
                <li>• Revisa la ubicación de productos Categoría A</li>
                <li>• Considera cambiar el método de inventario</li>
                <li>• Optimiza el uso del presupuesto</li>
                <li>• Mejora el flujo de trabajo del picking</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium">Si el score es alto (≥80):</h4>
              <ul className="text-sm space-y-1 text-slate-600">
                <li>• Intenta optimizar aún más el layout</li>
                <li>• Prueba diferentes configuraciones</li>
                <li>• Considera escenarios de mayor demanda</li>
                <li>• Documenta las mejores prácticas</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6 flex justify-center">
            <Button 
              onClick={() => window.location.href = '#layout'}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Volver a Layout para Mejorar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}