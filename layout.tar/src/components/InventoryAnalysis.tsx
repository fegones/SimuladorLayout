'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Product } from '@/app/page'
import { TrendingUp, TrendingDown, Minus, CheckCircle, AlertTriangle } from 'lucide-react'

interface InventoryAnalysisProps {
  products: Product[]
  inventoryMethod: 'fifo' | 'lifo'
  isSimulationComplete: boolean
  onDecisionsLocked?: (decisions: typeof userDecisions) => void
}

export default function InventoryAnalysis({ products, inventoryMethod, isSimulationComplete, onDecisionsLocked }: InventoryAnalysisProps) {
  // Estado para las decisiones del usuario
  const [userDecisions, setUserDecisions] = useState({
    reorderStrategy: '' as '' | 'value' | 'quantity' | 'rotation',
    storagePriority: '' as '' | 'category' | 'rotation' | 'value',
    auditFrequency: '' as '' | 'weekly' | 'monthly' | 'quarterly',
    safetyStock: '' as '' | 'conservative' | 'moderate' | 'aggressive'
  })
  
  // Estado para controlar si las decisiones están bloqueadas
  const [decisionsLocked, setDecisionsLocked] = useState(false)
  
  // Verificar si todas las decisiones han sido tomadas
  const allDecisionsMade = Object.values(userDecisions).every(decision => decision !== '')
  
  // Bloquear decisiones cuando se han tomado todas
  const handleDecisionChange = (decisionType: string, value: string) => {
    if (decisionsLocked || isSimulationComplete) return
    
    const newDecisions = { ...userDecisions, [decisionType]: value }
    setUserDecisions(newDecisions)
    
    // Verificar si todas las decisiones están tomadas
    const allMade = Object.values(newDecisions).every(decision => decision !== '')
    if (allMade && !decisionsLocked) {
      setDecisionsLocked(true)
      onDecisionsLocked?.(newDecisions)
    }
  }

  // Calcular estadísticas ABC
  const categoryA = products.filter(p => p.category === 'A')
  const categoryB = products.filter(p => p.category === 'B')
  const categoryC = products.filter(p => p.category === 'C')

  const totalValue = products.reduce((sum, p) => sum + (p.unitValue * p.quantity), 0)
  const valueA = categoryA.reduce((sum, p) => sum + (p.unitValue * p.quantity), 0)
  const valueB = categoryB.reduce((sum, p) => sum + (p.unitValue * p.quantity), 0)
  const valueC = categoryC.reduce((sum, p) => sum + (p.unitValue * p.quantity), 0)

  // Análisis de método de inventario
  const perishableProducts = products.filter(p => p.isPerishable)
  const highRotationProducts = products.filter(p => p.rotationSpeed === 'high')

  const getMethodRecommendation = () => {
    if (perishableProducts.length > products.length * 0.3) {
      return {
        recommended: 'fifo',
        reason: 'Tienes muchos productos perecederos. FIFO es ideal para evitar vencimientos.',
        score: 85
      }
    }
    if (highRotationProducts.length > products.length * 0.5) {
      return {
        recommended: 'fifo',
        reason: 'Alta rotación de productos. FIFO asegura venta de stock más antiguo.',
        score: 75
      }
    }
    return {
      recommended: 'lifo',
      reason: 'Productos estables con baja rotación. LIFO puede ofrecer ventajas fiscales.',
      score: 70
    }
  }

  const recommendation = getMethodRecommendation()

  // Evaluar decisiones del usuario
  const evaluateDecisions = () => {
    let score = 0
    let feedback = []

    // Evaluar estrategia de reorden
    if (userDecisions.reorderStrategy === 'value') {
      score += 25
      feedback.push('✅ Excelente: Priorizar por valor optimiza capital')
    } else if (userDecisions.reorderStrategy === 'rotation') {
      score += 20
      feedback.push('✅ Bueno: Priorizar rotación reduce obsolescencia')
    } else if (userDecisions.reorderStrategy === 'quantity') {
      score += 15
      feedback.push('⚠️ Regular: Priorizar cantidad puede ser ineficiente')
    } else {
      feedback.push('❌ Debes seleccionar una estrategia de reorden')
    }

    // Evaluar prioridad de almacenamiento
    if (userDecisions.storagePriority === 'category') {
      score += 25
      feedback.push('✅ Excelente: ABC es el método estándar de la industria')
    } else if (userDecisions.storagePriority === 'rotation') {
      score += 20
      feedback.push('✅ Bueno: La rotación es importante para el layout')
    } else if (userDecisions.storagePriority === 'value') {
      score += 15
      feedback.push('⚠️ Regular: El valor es importante pero no el único factor')
    } else {
      feedback.push('❌ Debes seleccionar una prioridad de almacenamiento')
    }

    // Evaluar frecuencia de auditoría
    if (userDecisions.auditFrequency === 'weekly') {
      score += 25
      feedback.push('✅ Excelente: Auditorías semanales previenen pérdidas')
    } else if (userDecisions.auditFrequency === 'monthly') {
      score += 20
      feedback.push('✅ Bueno: Mensual es aceptable para la mayoría')
    } else if (userDecisions.auditFrequency === 'quarterly') {
      score += 10
      feedback.push('⚠️ Regular: Trimestral puede ser muy espaciado')
    } else {
      feedback.push('❌ Debes seleccionar una frecuencia de auditoría')
    }

    // Evaluar stock de seguridad
    if (userDecisions.safetyStock === 'moderate') {
      score += 25
      feedback.push('✅ Excelente: Stock moderado balancea riesgo y costo')
    } else if (userDecisions.safetyStock === 'conservative') {
      score += 20
      feedback.push('✅ Bueno: Stock conservador es seguro pero costoso')
    } else if (userDecisions.safetyStock === 'aggressive') {
      score += 15
      feedback.push('⚠️ Regular: Stock agresivo puede causar faltantes')
    } else {
      feedback.push('❌ Debes seleccionar una política de stock')
    }

    return { score, feedback }
  }

  const { score: decisionScore, feedback: decisionFeedback } = evaluateDecisions()

  return (
    <div className="space-y-6">
      {/* Resumen General */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <div>
                <div className="text-sm text-slate-600">Categoría A</div>
                <div className="font-bold">{categoryA.length} productos</div>
                <div className="text-sm text-red-600">${valueA.toFixed(2)}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <div>
                <div className="text-sm text-slate-600">Categoría B</div>
                <div className="font-bold">{categoryB.length} productos</div>
                <div className="text-sm text-yellow-600">${valueB.toFixed(2)}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
              <div>
                <div className="text-sm text-slate-600">Categoría C</div>
                <div className="font-bold">{categoryC.length} productos</div>
                <div className="text-sm text-gray-600">${valueC.toFixed(2)}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <div>
                <div className="text-sm text-slate-600">Valor Total</div>
                <div className="font-bold">${totalValue.toFixed(2)}</div>
                <div className="text-sm text-green-600">{products.length} productos</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Decisiones del Usuario */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-500" />
            Toma de Decisiones de Inventario
            {decisionsLocked && (
              <Badge variant="default" className="ml-auto">
                <AlertTriangle className="w-3 h-3 mr-1" />
                Decisiones Bloqueadas
              </Badge>
            )}
          </CardTitle>
          {decisionsLocked && (
            <CardDescription className="text-orange-600">
              ⚠️ Las decisiones han sido bloqueadas. No se pueden cambiar hasta completar la simulación.
            </CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Estrategia de Reorden */}
            <div className="space-y-3">
              <h4 className="font-medium">1. Estrategia de Reorden</h4>
              <p className="text-sm text-slate-600">¿Cómo priorizarás los pedidos de reposición?</p>
              <div className="space-y-2">
                <Button
                  variant={userDecisions.reorderStrategy === 'value' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('reorderStrategy', 'value')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Por valor unitario (productos más caros primero)
                  {userDecisions.reorderStrategy === 'value' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.reorderStrategy === 'quantity' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('reorderStrategy', 'quantity')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Por cantidad (más unidades primero)
                  {userDecisions.reorderStrategy === 'quantity' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.reorderStrategy === 'rotation' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('reorderStrategy', 'rotation')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Por rotación (más vendidos primero)
                  {userDecisions.reorderStrategy === 'rotation' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
              </div>
            </div>

            {/* Prioridad de Almacenamiento */}
            <div className="space-y-3">
              <h4 className="font-medium">2. Prioridad de Almacenamiento</h4>
              <p className="text-sm text-slate-600">¿Qué factor priorizarás para la ubicación?</p>
              <div className="space-y-2">
                <Button
                  variant={userDecisions.storagePriority === 'category' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('storagePriority', 'category')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Categoría ABC (método estándar)
                  {userDecisions.storagePriority === 'category' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.storagePriority === 'rotation' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('storagePriority', 'rotation')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Velocidad de rotación
                  {userDecisions.storagePriority === 'rotation' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.storagePriority === 'value' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('storagePriority', 'value')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Valor del producto
                  {userDecisions.storagePriority === 'value' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
              </div>
            </div>

            {/* Frecuencia de Auditoría */}
            <div className="space-y-3">
              <h4 className="font-medium">3. Frecuencia de Auditoría</h4>
              <p className="text-sm text-slate-600">¿Cada cuándo realizarás inventario físico?</p>
              <div className="space-y-2">
                <Button
                  variant={userDecisions.auditFrequency === 'weekly' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('auditFrequency', 'weekly')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Semanal (máximo control)
                  {userDecisions.auditFrequency === 'weekly' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.auditFrequency === 'monthly' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('auditFrequency', 'monthly')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Mensual (balanceado)
                  {userDecisions.auditFrequency === 'monthly' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.auditFrequency === 'quarterly' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('auditFrequency', 'quarterly')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Trimestral (bajo costo)
                  {userDecisions.auditFrequency === 'quarterly' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
              </div>
            </div>

            {/* Stock de Seguridad */}
            <div className="space-y-3">
              <h4 className="font-medium">4. Política de Stock de Seguridad</h4>
              <p className="text-sm text-slate-600">¿Cuánto inventario extra mantenerás?</p>
              <div className="space-y-2">
                <Button
                  variant={userDecisions.safetyStock === 'conservative' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('safetyStock', 'conservative')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Conservador (30% extra)
                  {userDecisions.safetyStock === 'conservative' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.safetyStock === 'moderate' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('safetyStock', 'moderate')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Moderado (20% extra)
                  {userDecisions.safetyStock === 'moderate' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
                <Button
                  variant={userDecisions.safetyStock === 'aggressive' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => handleDecisionChange('safetyStock', 'aggressive')}
                  disabled={decisionsLocked || isSimulationComplete}
                >
                  Agresivo (10% extra)
                  {userDecisions.safetyStock === 'aggressive' && decisionsLocked && (
                    <CheckCircle className="w-4 h-4 ml-auto text-green-500" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Evaluación de Decisiones */}
          <div className="border-t pt-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium">Evaluación de tus Decisiones</h4>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Puntuación:</span>
                <Badge variant={decisionScore >= 80 ? 'default' : decisionScore >= 60 ? 'secondary' : 'destructive'}>
                  {decisionScore}/100
                </Badge>
              </div>
            </div>
            
            <div className="space-y-2">
              {decisionFeedback.map((feedback, index) => (
                <div key={index} className="text-sm p-2 bg-slate-50 rounded">
                  {feedback}
                </div>
              ))}
            </div>

            {decisionScore >= 80 && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 text-green-800">
                  <CheckCircle className="w-4 h-4" />
                  <span className="font-medium">¡Excelente estrategia de inventario!</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Análisis de Método de Inventario */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {inventoryMethod === 'fifo' ? (
              <TrendingDown className="w-5 h-5 text-blue-500" />
            ) : (
              <TrendingUp className="w-5 h-5 text-purple-500" />
            )}
            Análisis de Método: {inventoryMethod === 'fifo' ? 'FIFO' : 'LIFO'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h3 className="font-medium mb-2">Método Actual</h3>
              <p className="text-sm text-slate-600 mb-2">
                {inventoryMethod === 'fifo' 
                  ? 'First-In, First-Out: El primer producto en entrar es el primero en salir.'
                  : 'Last-In, First-Out: El último producto en entrar es el primero en salir.'
                }
              </p>
              <div className="text-sm">
                <div>Productos perecederos: {perishableProducts.length}</div>
                <div>Alta rotación: {highRotationProducts.length}</div>
              </div>
            </div>

            <div className={`p-4 rounded-lg ${
              recommendation.recommended === inventoryMethod ? 'bg-green-50' : 'bg-yellow-50'
            }`}>
              <h3 className="font-medium mb-2">Recomendación</h3>
              <p className="text-sm mb-2">{recommendation.reason}</p>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Método recomendado:</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  recommendation.recommended === 'fifo' 
                    ? 'bg-blue-100 text-blue-800' 
                    : 'bg-purple-100 text-purple-800'
                }`}>
                  {recommendation.recommended.toUpperCase()}
                </span>
                <span className="text-sm text-slate-600">
                  (Score: {recommendation.score}/100)
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detalle por Categoría */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Categoría A */}
        <Card>
          <CardHeader>
            <CardTitle className="text-red-700">🔴 Categoría A - Alta Prioridad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {categoryA.map(product => (
                <div key={product.id} className="p-3 bg-red-50 rounded-lg border border-red-200">
                  <div className="font-medium text-sm">{product.name}</div>
                  <div className="text-xs text-slate-600 mt-1">
                    <div>Valor: ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}</div>
                    <div>Rotación: {
                      product.rotationSpeed === 'high' ? 'Alta 🔥' :
                      product.rotationSpeed === 'medium' ? 'Media ⚡' : 'Baja 📊'
                    }</div>
                    {product.isPerishable && <div className="text-red-600">⚠️ Perecedero</div>}
                  </div>
                </div>
              ))}
            </div>
            {categoryA.length === 0 && (
              <div className="text-center text-slate-500 py-4">No hay productos en categoría A</div>
            )}
          </CardContent>
        </Card>

        {/* Categoría B */}
        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-700">🟡 Categoría B - Media Prioridad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {categoryB.map(product => (
                <div key={product.id} className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="font-medium text-sm">{product.name}</div>
                  <div className="text-xs text-slate-600 mt-1">
                    <div>Valor: ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}</div>
                    <div>Rotación: {
                      product.rotationSpeed === 'high' ? 'Alta 🔥' :
                      product.rotationSpeed === 'medium' ? 'Media ⚡' : 'Baja 📊'
                    }</div>
                    {product.isPerishable && <div className="text-red-600">⚠️ Perecedero</div>}
                  </div>
                </div>
              ))}
            </div>
            {categoryB.length === 0 && (
              <div className="text-center text-slate-500 py-4">No hay productos en categoría B</div>
            )}
          </CardContent>
        </Card>

        {/* Categoría C */}
        <Card>
          <CardHeader>
            <CardTitle className="text-gray-700">⚫ Categoría C - Baja Prioridad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {categoryC.map(product => (
                <div key={product.id} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="font-medium text-sm">{product.name}</div>
                  <div className="text-xs text-slate-600 mt-1">
                    <div>Valor: ${product.unitValue} × {product.quantity} = ${(product.unitValue * product.quantity).toFixed(2)}</div>
                    <div>Rotación: {
                      product.rotationSpeed === 'high' ? 'Alta 🔥' :
                      product.rotationSpeed === 'medium' ? 'Media ⚡' : 'Baja 📊'
                    }</div>
                    {product.isPerishable && <div className="text-red-600">⚠️ Perecedero</div>}
                  </div>
                </div>
              ))}
            </div>
            {categoryC.length === 0 && (
              <div className="text-center text-slate-500 py-4">No hay productos en categoría C</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recomendaciones de Layout */}
      <Card>
        <CardHeader>
          <CardTitle>📋 Recomendaciones de Layout Basadas en Inventario</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-red-700">Para Productos A:</h4>
              <ul className="text-sm space-y-1 text-slate-600">
                <li>• Colocar cerca del área de picking (≤ 3 casillas)</li>
                <li>• Acceso directo y fácil visibilidad</li>
                <li>• Espacio amplio para manipulación frecuente</li>
                <li>• Si son perecederos, usar FIFO obligatoriamente</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Para Productos C:</h4>
              <ul className="text-sm space-y-1 text-slate-600">
                <li>• Pueden estar en áreas lejanas (≥ 6 casillas)</li>
                <li>• Estanterías altas para optimizar espacio</li>
                <li>• Acceso menos frecuente es aceptable</li>
                <li>• Ideales para almacenamiento a largo plazo</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}